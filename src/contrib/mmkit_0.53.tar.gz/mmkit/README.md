
<img src="inst/icons/png/grayscale.png" alt="Drawing" style="width: 300px;"/>

Miscellaneous Functions Not Suitable for DelightfulFunctions, but nonetheless delightful.
Use this package if you are interested in:
 - making it easier to query and connect to databases
 - use substitution parameters so that you dont re-write your code
 - conform common variables
 - using uber-conf.

Enterprise licensing available.
