#' @title classified_names
#' @description A dataframe derived from ssa_national that contains names, classified
#' by the historical liklihood of gender membership, from 1978 to 1989.
"classified_names"
