options(stringsAsFactors = FALSE)
testthat::context('Test table creation')
suppressPackageStartupMessages(library(testthat))
suppressPackageStartupMessages(library(DelightfulFunctions))
setup({
  system("docker run --rm -d --name delightfulfuns -p 5432:5432 postgres")
  Sys.sleep(0.5)
})

test_tbl = "public.test_dev"
con = tryCatch({
  mmkit::db_conn('test_local')
}, error = function(e) {
  Sys.sleep(1)
  return(mmkit::db_conn('test_local'))
})

con$send("DROP TABLE IF EXISTS {{tbl}}", tbl=test_tbl)

df1 = data.frame(col1 = c('a', 'b', 'c'),
                colb = as.numeric(1.1, 2.2, 3.3),
                colc = as.integer(1:3))

# Test insert to new table
insert_resp = sql_insert(data=df1, con = con, table_name = test_tbl, 
                         redefine = T, debug = TRUE)
expect_true(insert_resp)

# Test table results match original dataframe
response = con$query("SELECT * FROM {{tbl}}", tbl=test_tbl)
expect_identical(response, df1)


df2 = data.frame(col1 = c('d', 'e', 'f'),
                colb = as.numeric(5.1, 6.2, 7.3),
                colc = as.integer(4:6))

# Test insert into existing table
insert_resp = sql_insert(data=df2, con = con, table_name = test_tbl, 
                         redefine = F, debug = TRUE)
expect_true(insert_resp)

# Test table results match original dataframe
response = con$query("SELECT * FROM {{tbl}}", tbl=test_tbl)
expect_identical(response, bind_rows(df1, df2))

con$disconnect()

teardown({
  system("docker stop delightfulfuns")
})
