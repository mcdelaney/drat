#' @title sql_define2
#'
#' @param  data dataframe to determine data types from
#' @param  table_name schema and table name string
#' @param  conn db_conn, RPostgreSQL, or dplyr connection object
#' @param  max.dec Integer. limits number of decimal places for numeric cols
#' @param  index.clause Character string of index / sort key clause to use. Must wrap variable names in ()
#' @param  redefine Logical. drops and redefines table if it exists
#' @param  lazy.cols Logical. defaults numeric columns to float8; all char to varchar(max)
#' @param  perms named vector/list of group permissions to grant (defaults to data_science_power_user:ALL; sf_data_analysts:SELECT)
#' @param  test.idf Logical. returns dataframe of datatypes determined from data.
#' @param  col.types A named list of database types to override automatic specification (e.g. list(column1 = 'varchar(42)', ...))
#' @param  define.args A vector/list of additional args to be passed to CREATE TABLE statement
#' @export

sql_define2 <- function(data, table_name, conn,
                       max.dec=NULL,
                       redefine=FALSE,
                       lazy.cols=FALSE,
                       index.clause=NULL,
                       perms='default',
                       test.idf=FALSE,
                       col.types=NULL,
                       define.args=NULL)
{
    sql. <- sql_factory(data = data,
                        table_name = table_name,
                        conn = conn,
                        redefine = redefine,
                        lazy.cols = lazy.cols,
                        max.dec = max.dec,
                        index.clause = index.clause,
                        perms = perms,
                        quietly = FALSE,
                        test.idf = test.idf,
                        col.types = col.types,
                        define.args = define.args,
                        operation = 'define')
    idf <- sql.$define()

    if (test.idf) {
        return(idf)
    }
    sql.$create()
    sql.$grant_permissions()
}


#' @title sql_define
#' @export
sql_define <- sql_define2
