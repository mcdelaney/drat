#' @title sql_insert2
#'
#' @param data dataframe to upload
#' @param table_name schema and table name string
#' @param conn db_conn, RPostgreSQL, or dplyr connection object
#' @param max.dec Integer. limits number of decimal places for numeric cols
#' @param redefine Logical. drops and redefines table if it exists
#' @param keep Logical. if redefine=TRUE, keep will bind existing table data to new data
#' @param bucket Character. Bucket name for copy command.
#' @param lazy.cols Logical. defaults numeric columns to float8; all char to text
#' @param index.clause Character string of index / sort key clause to use. Must wrap variable names in ()
#' @param blanks_as_null Logical. Specify if blank values should be interpreted as null.
#' @param overwrite Logical. deletes data contained in the table before inserting
#' @param truncate Logical. deletes data contained in the table via truncate command before inserting
#' @param del.params SQL-style string of conditions. Any table data meeting conditions will be deleted
#' @param perms named vector/list of group permissions to grant (defaults to data_science_power_user:ALL; sf_data_analysts:SELECT)
#' @param upload.type method of data upload. Options: ['s3_copy' (default), 'bulk_insert']
#' @param aws.creds Path to credentials for AWS. Reads ~/creds.json by default
#' @param quietly Logical. silences all status messages
#' @param analyze Logical. Runs ANALYZE command after upload
#' @param test.idf Logical. returns dataframe of datatypes determined from data.
#' @param col.types A named list of database types to override automatic specification (e.g. list(column1 = 'varchar(42)', ...))
#' @param ignore.cols A character vector of existing database columns to ignore in initial column check
#' @param define.args A vector/list of additional args to be passed to CREATE TABLE statement. (Only used if redefine=TRUE or table is new)
#' @export


sql_insert2 <- function(data, table_name, conn,
                        max.dec=NULL,
                        redefine=FALSE,
                        keep=FALSE,
                        lazy.cols=FALSE,
                        index.clause=NULL,
                        bucket=NULL,
                        overwrite=FALSE,
                        blanks_as_null=FALSE,
                        truncate=FALSE,
                        perms='default',
                        upload.type=c("copy","bulk_insert"),
                        aws.creds=NULL,
                        del.params="",
                        analyze=TRUE,
                        quietly=FALSE,
                        test.idf=FALSE,
                        col.types=NULL,
                        ignore.cols=NULL,
                        define.args=NULL,
                        debug=FALSE)
{
    upload.type <- match.arg(upload.type)

    sql. <- sql_factory(data = data,
                        table_name = table_name,
                        conn = conn,
                        bucket= bucket,
                        redefine = redefine,
                        lazy.cols = lazy.cols,
                        max.dec = max.dec,
                        blanks_as_null = blanks_as_null,
                        index.clause = index.clause,
                        perms = perms,
                        quietly = quietly,
                        test.idf = test.idf,
                        col.types = col.types,
                        define.args = define.args,
                        debug=debug)

    sql.$insert(upload.type = upload.type,
                keep = keep,
                overwrite = overwrite,
                del.params = del.params,
                truncate = truncate,
                aws.creds = aws.creds,
                analyze = analyze,
                ignore.cols = ignore.cols)
}


#' @title sql_insert
#' @export
sql_insert <- sql_insert2