#' @title unload_to_csv
#' @description Unload a redshift table to a series of csvs.
#' @import stringi
#' @import methods
#' @import jsonlite
#' @import RPostgreSQL


unload_to_csv <- function(con, table_name, aws_creds) {

    s3_path = gsub(" |:|-", "_", sprintf("redshift_unloads/%s_%s", table_name,
                                         Sys.time()))
    uq <- sprintf("UNLOAD ('select * from %s') TO 's3://corp-bi/%s'
                          CREDENTIALS 'aws_access_key_id=%s;aws_secret_access_key=%s'
                  DELIMITER '|' MANIFEST GZIP ALLOWOVERWRITE",
                  table_name,
                  s3_path,
                  aws_creds$aws_access_key_id,
                  aws_creds$aws_secret_access_key)
    dbSendQuery(conn[[1]]$con, uq)

    message("UNLOAD QUERY EXECUTED")
    # Download and combine

    manifest <- jsonlite::fromJSON(rawToChar(
        get_s3_object(s3_path = paste0(s3_path, 'manifest'),
                      key = aws_creds$aws_access_key_id,
                      secret = aws_creds$aws_secret_access_key)
    ))$entries$url

    paths <- unlist(lapply(manifest, function(key) {
        s3_path <- strsplit(key,
                            paste0(formals(get_s3_object)$bucket,'/'))[[1]][2]
        path <- file.path(local_path, basename(key))
        save_s3_object(s3_path = s3_path,
                       file = path,
                       key = aws_creds$aws_access_key_id,
                       secret = aws_creds$aws_secret_access_key)
        return(path)
    }))

}
