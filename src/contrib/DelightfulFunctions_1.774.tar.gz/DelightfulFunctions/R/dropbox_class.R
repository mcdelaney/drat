#' @name dropr
#' @title An R interface to Dropbox
#' @description A \code{\link[=ReferenceClasses]{ReferenceClass}} object with methods to interact with the Dropbox v2 API
#' @import jsonlite
#' @import httr
#'
#' @export
#'
#' @section Initialization:
#' \preformatted{
#' db <- src_dropbox()
#' }
#'
#' @section Methods:
#' \describe{
#' \item{\describe{
#'  \strong{DIR}\preformatted{
#'  }\emph{Lists the contents of a Dropbox directory}\preformatted{
#'  db$dir(dropbox_path,
#'         recursive = FALSE,
#'         simplify = TRUE)}
#' }}{\describe{
#'  \item{dropbox_path}{A directory on Dropbox}
#'  \item{recursive}{Should the contents of subfolders be reported?}
#'  \item{simplify}{If TRUE, returns a vector of filenames; if FALSE, a dataframe with additional metadata}
#' }}
#' \item{\describe{
#'  \strong{LS}\preformatted{
#'  }\emph{Alias for }\code{dir()}}}{}
#' \item{\describe{
#'  \strong{COPY}\preformatted{
#'  }\emph{Copy a file on Dropbox}\preformatted{
#' db$copy(from_path,
#'         to_path,
#'         overwrite = TRUE)}
#' }}{\describe{
#'  \item{from_path}{The source file on Dropbox}
#'  \item{to_path}{The target directory or full file path. If no filename is provided, the filename in from_path is used}
#'  \item{overwrite}{If TRUE, an attempt is made to delete the target file before the copy operation occurs}
#' }}
#' \item{\describe{
#'  \strong{MOVE}\preformatted{
#'  }\emph{Move a file on Dropbox}\preformatted{
#' db$move(from_path,
#'         to_path,
#'         overwrite = TRUE)}
#' }}{\describe{
#'  \item{from_path}{The source file on Dropbox}
#'  \item{to_path}{The target directory or full file path. If no filename is provided, the filename in from_path is used}
#'  \item{overwrite}{If TRUE, an attempt is made to delete the target file before the move operation occurs}
#' }}
#' \item{\describe{
#'  \strong{DELETE}\preformatted{
#'  }\emph{Delete a Dropbox file}\preformatted{
#' db$delete(dropbox_path)}
#' }}{\describe{
#'  \item{dropbox_path}{The file or folder to delete}
#' }}
#' \item{\describe{
#'  \strong{GET}\preformatted{
#'  }\emph{Download a Dropbox file}\preformatted{
#' db$get(dropbox_path)}
#' }}{\describe{
#'  \item{dropbox_path}{A Dropbox file path}
#' }}
#' \item{\describe{
#'  \strong{SAVE}\preformatted{
#'  }\emph{Download a Dropbox file to disk}\preformatted{
#' db$save(dropbox_path,
#'         file_path)}
#' }}{\describe{
#'  \item{dropbox_path}{A Dropbox file path}
#'  \item{file_path}{A local file path}
#' }}
#' \item{\describe{
#'  \strong{PUT}\preformatted{
#'  }\emph{Upload a file to Dropbox}\preformatted{
#' db$put(file_path,
#'        dropbox_path,
#'        ...)}
#'  }}{\describe{
#'  \item{file_path}{A local file path}
#'  \item{dropbox_path}{The target directory or full file path. If no filename is provided, the filename in file_path is used}
#'  \item{...}{Other arguments passed to \code{put_big_}}
#' }}}
#'
#' @section Examples:
#' \preformatted{
#' db <- src_dropbox(token_path = '~/tokens/db_token.Rds')
#'
#' db$dir(dropbox_path = 'remoteDir')
#'
#' db$get(dropbox_path = 'remoteDir/someFile.Rds')
#'
#' db$save(dropbox_path = 'remoteDir/somefile.Rds',
#'         file_path = '~/localDir/')
#'
#' db$put(file_path = '~/localDir/someFile.Rds',
#'        dropbox_path = 'remoteDir/')
#'
#' db$copy(from_path = 'remoteDir/someFile.Rds',
#'         to_path = 'remoteDir2/')
#'
#' db$move(from_path = 'remoteDir/someFile.Rds',
#'         to_path = 'remoteDir2/')
#'
#' db$delete(dropbox_path = 'remoteDir2/someFile.Rds')
#' }

dropr <- setRefClass(
    Class   = 'dropr',
    fields  = list(
        base_url = 'character',
        htcfg    = 'list',
        opcfg    = 'list',
        verbose  = 'logical'
    ),
    methods = list(
        initialize = function(token_path,
                              verbose,
                              ...)
        {
            require(httr)

            message(sprintf("Reading Dropbox token from '%s'", token_path))

            base_url <<- "https://%s.dropboxapi.com/2/%s"
            htcfg    <<- list(config(token = readRDS(token_path)))
            opcfg    <<- jsonlite::fromJSON(
                system.file('dbcfg.json', package = 'DelightfulFunctions')
            )
            verbose  <<- verbose
        },

        help = function()
        {
            ?dropr
        },

        check_path_ = function(dropbox_path)
        {
            if (nchar(dropbox_path) && !grepl('^/', dropbox_path)) {
                dropbox_path <- paste0('/', dropbox_path)
            }
            gsub('/$', '', dropbox_path)
        },

        append_path_ = function(file_path, dropbox_path)
        {
            if (grepl("\\.[[:alnum:]]{1,}$", basename(dropbox_path))) {
                dropbox_path
            } else {
                file.path(dropbox_path, basename(file_path))
            }
        },

        build_url_ = function(operation)
        {
            url <- sprintf(.self$base_url,
                           opcfg[[operation]]$subdom,
                           opcfg[[operation]]$endpt )

            return(URLencode(url))
        },

        toJSON_ = function(x)
        {
            if (is.null(x)) {
                x
            } else {
                jsonlite::toJSON(x, auto_unbox = T)
            }
        },

        request_ = function(operation,
                            arg  = NULL,
                            body = NULL)
        {
            url    <- build_url_(operation)

            .headers <- c(`Content-Type`    = opcfg[[operation]]$type,
                          `Dropbox-API-Arg` = toJSON_(arg))

            if (verbose) {
                message("Request URL: \n  ", url)
                message("Request headers:")
                message(paste(collapse = '\n',
                              sprintf("  %s = %s", names(.headers), .headers)) )
            }

            if (opcfg[[operation]]$subdom == 'api') {
                body <- toJSON_(body)

                if (verbose) {
                    message("Request body: \n  ", body)
                }
            }

            res <- httr::POST(url,
                              config = .self$htcfg[[1]],
                              httr::add_headers(.headers = .headers),
                              body = body)

            return(handle_response_(res, operation))
        },

        handle_response_ = function(response, operation)
        {
            stat <- response$status

            if (stat < 300) {
                if (verbose) {
                    message(sprintf("Response status code:\n  %s\n  ", stat))
                }
                return(response)
            } else {
                msg <- sprintf(paste(sep = '\n  * ','',
                             "Request URL: \'%s\'",
                             "Status code: %s",
                             "Error text: %s"),
                       response$url,
                       stat,
                       rawToChar(response$content))
                stop(msg)
            }
        },

        content_ = function(response, ...)
        {
            jsonlite::fromJSON(rawToChar(response$content), ...)
        },

        dir_ = function(dropbox_path, recursive, cursor = '')
        {
            if (nchar(cursor)) {
                body <- list(cursor = cursor)
                req. <- 'dir_cont'
            } else {
                body <- list(path = dropbox_path,
                             recursive = recursive)
                req. <- 'dir'
            }

            return(
                content_(
                    request_(req., body = body),
                    simplifyDataFrame = FALSE
                )
            )
        },

        copy_move_ = function(from_path, to_path, overwrite, operation)
        {
            from_path <- check_path_(from_path)
            to_path   <- check_path_(to_path)

            to_path <- append_path_(from_path, to_path)

            if (overwrite) {
                try(.self$delete(to_path), silent = TRUE)
            }

            resp <- request_(operation,
                             body = list(from_path = from_path,
                                         to_path = to_path) )

            message(sprintf("%s operation successful (\'%s\' -> \'%s\')",
                            toupper(operation),
                            from_path, to_path))

            return(TRUE)
        },

        dir = function(dropbox_path, recursive = FALSE, simplify = TRUE)
        {
            dropbox_path <- check_path_(dropbox_path)

            res <- dir_(dropbox_path, recursive)

            data <- res$entries

            while (res$has_more) {
                res  <- dir_(dropbox_path, recursive, cursor = res$cursor)
                data <- append(data, res$entries)
            }

            data <- jsonlite:::simplifyDataFrame(data, flatten = TRUE)
            data <- data[data$path_lower != tolower(dropbox_path), ]

            if (simplify) {
                if (recursive) {
                    return(data$path_display)
                }
                return(data$name)
            } else {
                return(data)
            }
        },

        ls = function(dropbox_path, recursive = FALSE, simplify = TRUE)
        {
            dir(dropbox_path, recursive, simplify)
        },

        copy = function(from_path, to_path, overwrite = TRUE)
        {
            copy_move_(from_path, to_path, overwrite, 'copy')
        },

        move = function(from_path, to_path, overwrite = TRUE)
        {
            copy_move_(from_path, to_path, overwrite, 'move')
        },

        delete = function(dropbox_path)
        {
            dropbox_path <- check_path_(dropbox_path)

            request_('delete', body = list(path = dropbox_path))

            return(TRUE)
        },

        get = function(dropbox_path)
        {
            dropbox_path <- check_path_(dropbox_path)

            message(sprintf("Fetching \'%s\' from Dropbox", dropbox_path))

            resp <- request_('get', arg = list(path = dropbox_path))
            return(resp$content)
        },

        save = function(dropbox_path, file_path)
        {
            raw. <- .self$get(dropbox_path)

            message(sprintf("Saving file to \'%s\' (%s bytes)",
                            file_path, length(raw.)))

            ftag <- file(file_path, "wb")
            writeBin(raw., ftag)
            close(ftag)

            return(TRUE)
        },

        put = function(file_path, dropbox_path, ...)
        {
            if ( !file.exists(file_path)) {
                stop(sprintf("Local file \'%s\' does not exist", file_path))
            } else {
                message(sprintf("Uploading local file \'%s\' to Dropbox",
                                file_path))
            }

            dropbox_path <- append_path_(file_path, check_path_(dropbox_path))

            file_size <- file.size(file_path)

            if (file_size < 140*1024**2) {
                put_(file_path, dropbox_path)
            } else {
                put_big_(file_path, dropbox_path, file_size, ...)
            }

            return(TRUE)
        },

        put_ = function(file_path, dropbox_path)
        {
            request_('put',
                     arg  = list(path = dropbox_path,
                                 mode = 'overwrite'),
                     body = upload_file(file_path) )

            message(sprintf("File successfully uploaded to Dropbox location \'%s\'",
                            dropbox_path))
        },

        put_big_ = function(file_path, dropbox_path, file_size, chunk.size = 20*1024**2)
        {
            message(sprintf(
                "Large file (%s B) - beginning chunked upload (%s B chunks)...",
                file_size, chunk.size))

            whole <- readBin(file_path, "raw", file_size)

            resp. <- request_('start_chunked')
            session_id <- content_(resp.)$session_id

            offset  <- 0
            cur.end <- chunk.size

            while (cur.end < file_size | offset == 0) {
                cur.end <- offset + chunk.size
                body <- whole[(offset+1):(ifelse(cur.end > file_size, file_size, cur.end))]

                tresp <- request_('append_chunked',
                                  body = body,
                                  arg = list(cursor = list(session_id = session_id,
                                                           offset     = offset) )
                )
                offset <- offset + length(body)

                if (verbose) {
                    message(sprintf("Uploaded %s of %s bytes", offset, file_size))
                }
            }

            if (offset == file_size) {
                com <- request_(
                    'commit_chunked',
                    arg = list(cursor = list(session_id = session_id,
                                             offset     = offset),
                               commit = list(path = dropbox_path,
                                             mode = 'overwrite') )
                )
            }
            message(sprintf("File successfully uploaded to Dropbox location \'%s\'",
                            content_(com)$path_display))
        }
    )
)
