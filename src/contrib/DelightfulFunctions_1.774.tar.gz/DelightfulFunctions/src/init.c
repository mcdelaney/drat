#include "delightfulfunctions.h"
#include <Rdefines.h>
#include <R_ext/Rdynload.h>
#include <R_ext/Visibility.h>

// .Calls
SEXP writefile();

static const
R_CallMethodDef callMethods[] = {
{"Cwritefile", (DL_FUNC) &writefile, -1},
{NULL, NULL, 0}
};

void attribute_visible R_init_delightfulfunctions(DllInfo *info)
// relies on pkg/src/Makevars to mv delightfulfunctions.so
{
    R_registerRoutines(info, NULL, callMethods, NULL, NULL);
    R_useDynamicSymbols(info, FALSE);
}
