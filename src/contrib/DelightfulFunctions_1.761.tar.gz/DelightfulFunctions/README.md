DelightfulFunctions
===================

This is a repository of Delightful Functions for use in R
