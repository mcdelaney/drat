#' @title generate_keyword_list
#' @param  prog_names full formal name of program to lookup
#' @param  other_acronyms other abbreviations shortened forms of the degree name - ex: msw
#' @param  abbrevs shortened forms of the program ex: computer science = CS
#' @export
#'

generate_keyword_list <- function(prog_names,
                                  other_acronyms = NULL,
                                  abbrevs = NULL){

    prog_names <- tolower(prog_names)

    acronyms <- c("master", "masters", "ms")

    if (is.null(other_acronyms) == FALSE) {
        acronyms <- c(acronyms, abbrevs)
    }

    if (is.null(abbrevs)) {
        abbrev_list <- prog_names
    }else{
        abbrev_list <- c(prog_names, abbrevs)
    }

    acronyms <- expand.grid(stringsAsFactors = F,
                            prog = abbrev_list,
                            splits = c("of", "in"),
                            degree = acronyms)
    acronyms$term1 <- paste0(acronyms$degree, " ", acronyms$splits, " ", acronyms$prog)
    acronyms$term <- paste0(acronyms$prog, " ", acronyms$degree)

    acronyms2 <- expand.grid(stringsAsFactors = F,
                             desc = c("top", "best", "top ranked"),
                             prog = abbrev_list)
    acronyms2$terms <- paste(acronyms2$desc, acronyms2$prog, "program")

    terms <- c(as.character(acronyms$term1), as.character(acronyms$term2),
               as.character(acronyms2$terms))

    plural <- terms[grepl("program", terms)]
    plural <- gsub("program", replacement = "programs", plural)

    terms <- c(terms, plural)

    terms <- c(terms, paste(terms, "online"), paste("online", terms))

    if (!is.null(other_acronyms)) {
        terms <- c(terms,
                   paste(c("top","best",""), "executive",other_acronyms, "programs"),
                   paste("executive",other_acronyms, "rankings"),
                   paste("online", "executive", other_acronyms, "programs"),
                   paste("online", "executive",other_acronyms, "rankings"),
                   paste("online", "executive",other_acronyms),
                   paste(c("top","best",""), other_acronyms, "programs"),
                   paste(other_acronyms, "rankings"),
                   paste("online", other_acronyms, "programs"),
                   paste("online", other_acronyms, "rankings"),
                   paste("online", other_acronyms))
    }
    terms <- gsub("^\\s+|\\s+$", "", terms)

    terms <- tolower(terms[!duplicated(terms)])

    terms <- unique(terms)

    return(terms)
}