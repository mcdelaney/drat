#' @title List s3 bucket contents
#'
#' @param s3_prefix Limits the response to keys that begin with the specified character string
#' @param bucket The name of the desired s3_bucket. Defaults to 'corp-bi'
#' @param simplify Logical. If `TRUE`, a vector of key names; if `FALSE`, a data.frame with additional info
#' @param key AWS Access Key ID. Defaults to environment var 'AWS_ACCESS_KEY_ID'
#' @param secret AWS Secret Access Key. Defaults to environment var 'AWS_SECRET_ACCESS_KEY'
#' @param region AWS region. Defaults to 'us-east-1' or environment var 'AWS_DEFAULT_REGION'
#'
#' @import httr
#' @import XML
#' @import base64enc
#' @import digest
#'
#' @export

ls3 <- function(s3_prefix,
                bucket = 'corp-bi',
                simplify = TRUE,
                key = Sys.getenv('AWS_ACCESS_KEY_ID'),
                secret = Sys.getenv('AWS_SECRET_ACCESS_KEY'),
                region = Sys.getenv('AWS_DEFAULT_REGION','us-east-1'))
{
    parsed <- getbucket_(s3_prefix, bucket, key, secret, region)$parsed

    truncated <- tolower(parsed$IsTruncated) == 'true'

    if (truncated) {
        message(sprintf("The prefix '%s' matches >1000 keys! This may take a while...",
                        s3_prefix))
    }

    while (truncated) {
        marker <- parsed[length(parsed)]$Contents$Key

        parsed <- append(
            parsed,
            getbucket_(s3_prefix, bucket, key, secret, region, marker = marker)$parsed
        )
        truncated <- tolower(parsed$IsTruncated) == 'true'

        parsed <- parsed[names(parsed) == 'Contents']
    }

    if (simplify) {
        res <- unlist(parsed)
        res <- unname(res[which(names(res) == 'Contents.Key')])
    } else {
        res <- bind_rows(lapply(
            parsed[which(names(parsed) == 'Contents')],
            function(x) {
                df <- data.frame(x)
                names(df) <- gsub('contents.','', tolower(names(df)), fixed = T)
                return(df)
            }
        ))
        row.names(res) <- NULL
    }
    return(res)
}



#' @title Get an RDS3 object from s3
#'
#' @param s3_path Full s3 file path of the object to be retrieved
#' @param bucket The name of the desired s3_bucket. Defaults to 'corp-bi'
#' @param key AWS Access Key ID. Defaults to environment var 'AWS_ACCESS_KEY_ID'
#' @param secret AWS Secret Access Key. Defaults to environment var 'AWS_SECRET_ACCESS_KEY'
#' @param region AWS region. Defaults to 'us-east-1' or environment var 'AWS_DEFAULT_REGION'
#' @param parse_response Logical. Should RDS3 content be converted back to R object? Default: TRUE.
#'
#' @export

get_s3_object <- function(s3_path,
                          bucket = 'corp-bi',
                          key = Sys.getenv('AWS_ACCESS_KEY_ID'),
                          secret = Sys.getenv('AWS_SECRET_ACCESS_KEY'),
                          region = Sys.getenv('AWS_DEFAULT_REGION','us-east-1'),
                          parse_response = TRUE)
{
    message(sprintf("Fetching \'%s\' from s3", s3_path))

    error_func <- function(e) {
        Sys.sleep(3);
        getobject_(s3_path, bucket, key, secret, region)
    }

    response <- tryCatch(
        getobject_(s3_path, bucket, key, secret, region),
        error = error_func,
        warning = error_func
        )

    check_s3_response(response)

    if (parse_response && rawToChar(response$content[1:2]) == "x\x9c") {
        return(loadRDS3(response$content))
    } else {
        return(response$content)
    }
}



#' @title Save an RDS3 object from s3
#'
#' @param s3_path Full s3 file path of the object to be retrieved
#' @param path File path or connection to write
#' @param bucket The name of the desired s3_bucket. Defaults to 'corp-bi'
#' @param key AWS Access Key ID. Defaults to environment var 'AWS_ACCESS_KEY_ID'
#' @param secret AWS Secret Access Key. Defaults to environment var 'AWS_SECRET_ACCESS_KEY'
#' @param region AWS region. Defaults to 'us-east-1' or environment var 'AWS_DEFAULT_REGION'
#'
#' @export

save_s3_object <- function(s3_path,
                           file,
                           bucket = 'corp-bi',
                           key = Sys.getenv('AWS_ACCESS_KEY_ID'),
                           secret = Sys.getenv('AWS_SECRET_ACCESS_KEY'),
                           region = Sys.getenv('AWS_DEFAULT_REGION','us-east-1') )
{
    if (is.character(file)) {
        file <- path.expand(file)
    }

    writeBin(
        object = get_s3_object(s3_path = s3_path,
                               bucket = bucket,
                               key = key,
                               secret = secret,
                               region = region,
                               parse_response = FALSE),
        con = file
    )
    return(TRUE)
}



#' @title Upload an RDS3 object or file to s3
#'
#' @param file Either the object to be uploaded, or a local file path
#' @param s3_path Full s3 file path of the object to be uploaded
#' @param bucket The name of the desired s3_bucket. Defaults to 'corp-bi'
#' @param key AWS Access Key ID. Defaults to environment var 'AWS_ACCESS_KEY_ID'
#' @param secret AWS Secret Access Key. Defaults to environment var 'AWS_SECRET_ACCESS_KEY'
#' @param region AWS region. Defaults to 'us-east-1' or environment var 'AWS_DEFAULT_REGION'
#' @param overwrite Logical. Should we overwrite existing data at s3_path? Defaults to TRUE
#'
#' @export

put_s3_object <- function(file,
                          s3_path,
                          bucket = 'corp-bi',
                          key = Sys.getenv('AWS_ACCESS_KEY_ID'),
                          secret = Sys.getenv('AWS_SECRET_ACCESS_KEY'),
                          region = Sys.getenv('AWS_DEFAULT_REGION','us-east-1'),
                          overwrite = TRUE)
{
    if (grepl("\\s", s3_path)) {
        stop(sprintf('s3_path \'%s\' contains spaces', s3_path))
    } else {
        message(sprintf('Uploading \'%s\' to s3', s3_path))
    }

    if (is.character(file) && !file.exists(file)) {
        stop(sprintf('Local file \'%s\' does not exist', file))
    }

    chk <- character(0)
    err.cnt <- 0
    status  <- NULL

    if ( !overwrite) {
        chk <- check_if_exists(s3_path, bucket, key, secret, region)
        if (length(chk)) {
            stop(sprintf('S3 file \'%s\' already exists. Set overwrite = TRUE to replace it',
                         s3_path))
        }
    }

    while ( !length(chk) & err.cnt < 3) {
        response <- tryCatch(
            {
                putobject_(file = handle_file(file),
                           bucket = bucket,
                           object = s3_path,
                           key = key,
                           secret = secret,
                           region = region)
            },
            error = function(e) return(e)
        )

        status <- check_s3_response(response, on.error = 'warn')

        if (is.null(status)) {
            err.cnt <- err.cnt + 1
        }

        hdrs <- unlist(lapply(1:length(response$headers),
                              function(i) sprintf("%s: %s",
                                                  names(response$headers)[i],
                                                  response$headers[[i]])))

        msg <- sprintf(paste(sep = '\n  * ','',
                             "Status code: %s",
                             "Response headers: %s"),
                       response$status_code,
                       paste(collapse = '\n         ',c('',hdrs)))
        message(msg)

        if ( !is.null(status) && status < 300) {
            chk <- check_if_exists(s3_path, bucket, key, secret, region)
        }
    }

    if (length(chk)) {
        message(sprintf('File \'%s\' successfully uploaded and verified to exist',
                        chk))
        return(TRUE)
    }
    else {
        stop(sprintf('Upload failure for file \'%s\' - Maximum retries reached',
                     s3_path))
    }
}



#' @title Fetch and combine RDS3 objects to a data frame
#'
#' @param s3_paths One or more full s3 file paths to be fetched
#' @param bucket The name of the desired s3_bucket. Defaults to 'corp-bi'
#' @param key AWS Access Key ID. Defaults to environment var 'AWS_ACCESS_KEY_ID'
#' @param secret AWS Secret Access Key. Defaults to environment var 'AWS_SECRET_ACCESS_KEY'
#' @param region AWS region. Defaults to 'us-east-1' or environment var 'AWS_DEFAULT_REGION'

#'
#' @export

combine_s3 <- function(s3_paths,
                       bucket = 'corp-bi',
                       key = Sys.getenv('AWS_ACCESS_KEY_ID'),
                       secret = Sys.getenv('AWS_SECRET_ACCESS_KEY'),
                       region = Sys.getenv('AWS_DEFAULT_REGION','us-east-1') )
{
    if ('dplyr' %in% row.names(installed.packages())) {
        bind_rows <- dplyr::bind_rows
    }

    bind_rows(lapply(s3_paths, function(x) {

        res <- get_s3_object(x,
                             bucket = bucket,
                             key = key,
                             secret = secret,
                             region = region)

        if (inherits(res, 'data.frame')) {
            return(res)
        } else {
            warning(sprintf("Object \'%s\' is not a RDS3 dataframe", x))
            return(NULL)
        }
    }))
}



#' @title Fetch, combine, and insert RDS3 objects to a SQL database
#'
#' @param s3_paths One or more full s3 file paths to be fetched
#' @param bucket The name of the desired s3_bucket. Defaults to 'corp-bi'
#' @param key AWS Access Key ID. Defaults to environment var 'AWS_ACCESS_KEY_ID'
#' @param secret AWS Secret Access Key. Defaults to environment var 'AWS_SECRET_ACCESS_KEY'
#' @param region AWS region. Defaults to 'us-east-1' or environment var 'AWS_DEFAULT_REGION'
#' @param ... Other arguments to be passed to \code{sql_insert2}
#'
#' @export

combine_and_insert <- function(s3_paths,
                               bucket = 'corp-bi',
                               key = Sys.getenv('AWS_ACCESS_KEY_ID'),
                               secret = Sys.getenv('AWS_SECRET_ACCESS_KEY'),
                               region = Sys.getenv('AWS_DEFAULT_REGION','us-east-1'),
                               ...)
{
    message("Collecting...")
    data <- combine_s3(s3_paths, bucket, key, secret, region)

    if (nrow(data)) {
        message("Inserting...")
        sql_insert2(data, ...)
    } else {
        warning("No data to insert")
    }
}






### helpers


getbucket_ <- function(s3_prefix, bucket, key, secret, region, marker = NULL, ...)
{
    query = list(prefix = s3_prefix, delimiter = NULL, `max-keys` = NULL,
                 marker = marker)

    response <- s3HTTP(verb = "GET",
                       bucket = bucket,
                       query = query,
                       key = key,
                       secret = secret,
                       region = region,
                       ...)

    status <- check_s3_response(response, ...)
    parsed <- parse_s3_response(response)

    return(list(status = status, parsed = parsed))
}



getobject_ <- function(s3_path, bucket, key, secret, region, headers = list(), ...)
{
    if (inherits(s3_path, "s3_object"))
        s3_path <- s3_path$Key

    r <- s3HTTP(
        verb = "GET",
        bucket = bucket,
        path = paste0("/", s3_path),
        headers = headers,
        key = key,
        secret = secret,
        region = region,
        ...)

    return(r)
}



putobject_ <- function(file, bucket, object, key, secret, region, headers = list(), ...)
{
    if (!missing(object) && inherits(object, "s3_object"))
        object <- object$Key
    if (missing(object)) {
        object <- basename(file)
    }
    r <- s3HTTP(
        verb = "PUT",
        bucket = bucket,
        path = paste0("/",object),
        headers = c(headers,
                    list(`Content-Length` = ifelse(is.character(file) && file.exists(file),
                                                   file.size(file), length(file))) ),
        request_body = file,
        key = key,
        secret = secret,
        region = region,
        ...)

    return(r)
}


parse_s3_response <- function(response)
{
    XML::xmlToList(
        XML::xmlParse(
            httr::content(
                x = response, as = 'text', encoding = 'UTF-8'),
        asText = TRUE)
    )
}


check_s3_response <- function(response, on.error = 'stop', ...)
{
    if (inherits(response, 'error')) {
        warning(response$message, call. = FALSE, immediate. = TRUE)
        Sys.sleep(2)
        return(NULL)
    }

    # list of http status codes to attempt retry of current operation
    # http://docs.aws.amazon.com/AmazonS3/latest/API/ErrorResponses.html
    retry_codes <- c(500, 502, 503, 409, 307)

    if (response$status_code > 200) {
        error_text <- tryCatch(
            parse_s3_response(response)$Message,
            error = function(e) { rawToChar(response$content) }
            )

        msg <- sprintf(paste(sep = '\n  * ','',
                             "Request URL: \'%s\'",
                             "Status code: %s",
                             "Error text: %s"),
                       response$url,
                       response$status_code,
                       error_text)
        if (grepl('denied', tolower(error_text))) {
            msg <- paste(sep = '\n  ** ', msg,
                      "Oops! This is a private bucket !!!",
                      "Please ensure you are passing credentials via either:",
                      " -> Function args 'key' and 'secret'",
                      " -> Environment variables `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`")
        }
        if (response$status_code == 301) {
            msg <- paste(sep = '\n  ** ', msg,
                      "Please ensure you are passing the correct region via either:",
                      " -> Function arg 'region'",
                      " -> Environment variable `AWS_DEFAULT_REGION`")
        }

        if (on.error == 'stop' | !response$status_code %in% retry_codes) {
            stop(msg, call. = FALSE)
        } else {
            warning(msg, call. = FALSE, immediate. = TRUE)
        }
    }
    return(response$status_code)
}


check_if_exists <- function(s3_path, bucket, key, secret, region)
{
    chk <- getbucket_(s3_path, bucket, key, secret, region, on.error = 'warn')

    if (chk$status > 200) {
        Sys.sleep(3)
        chk <- getbucket_(s3_path, bucket, key, secret, region, on.error = 'warn')
    }

    return(chk$parsed$Contents$Key)
}


handle_file <- function(file)
{
    if (is.character(file) && file.exists(file)) {
        return(file)
    } else {
        return(saveRDS3(file, compress = T))
    }
}
