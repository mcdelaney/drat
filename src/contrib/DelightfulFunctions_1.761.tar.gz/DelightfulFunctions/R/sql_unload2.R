#' @title sql_unload2
#'
#' @param table Character. Table to unload (requires schema name). Supports conditionals. 'schema.table [where ...]'
#' @param conn db_conn, RPostgreSQL, or dplyr connection object
#' @param aws.creds List. Credentials for AWS. Reads ~/creds.json by default
#'
#'
#' @export

sql_unload2 <- function(table, conn, aws.creds=NULL)
{
    sql. <- sql_factory(data.frame(NULL),
                        table_name = table,
                        conn = conn,
                        operation = 'unload')

    data <- sql.$unload(aws.creds)

    return(data)
}


#' @title sql_unload
#' @export
sql_unload <- sql_unload2