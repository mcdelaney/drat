#' @title sql_factory
#' @description Where all the magic happens!
#' @import stringi
#' @import methods
#' @import jsonlite
#' @import RPostgreSQL
#' @useDynLib delightfulfunctions, .registration = TRUE
#'

sql_factory <- suppressWarnings(setRefClass(
    Class  = "sql_factory",
    fields = list(
        data         = "data.frame",
        table_name   = "character",
        conn         = "list",
        conn_type    = "character",
        perms        = "list",
        redefine     = "logical",
        lazy.cols    = "logical",
        blanks_as_null = "logical",
        max.dec      = "numeric",
        index.clause = "character",
        bucket = "character",
        upload.type  = "character",
        delimiter    = "character",
        aws.creds    = "list",
        lib_path     = "character",
        quietly      = "logical",
        test.idf     = "logical",
        col.types    = "list",
        define.args  = "list",
        overwrite    = "logical",
        del.params   = "character",
        truncate     = "logical",
        reset.opts   = "list",
        t0           = "numeric",
        t00          = "numeric",
        attempts     = "numeric",
        max_attempts = "numeric",
        types        = "data.frame",
        idf          = "data.frame",
        pgtypes      = "data.frame",
        transaction  = "logical",
        operation    = "character"
    ),
    methods = list(

        ##################################################
        ## INITIALIZATION METHODS #######################
        #################################################

        initialize = function(data,  table_name,  conn,
                              redefine  = FALSE,
                              lazy.cols = FALSE,
                              max.dec   = NULL,
                              index.clause = NULL,
                              bucket = "corp-bi",
                              blanks_as_null = FALSE,
                              perms = 'default',
                              quietly = FALSE,
                              test.idf = FALSE,
                              col.types = NULL,
                              define.args = NULL,
                              operation = 'insert',
                              ...) {
            if ( !grepl("\\.",table_name)) stop("table_name must contain schema")

            .self$handle_opts()
            .self$handle_conn(conn)

            perms        <<- as.list(perms)
            table_name   <<- table_name
            redefine     <<- redefine
            bucket     <<- bucket
            lazy.cols    <<- lazy.cols
            quietly      <<- quietly
            blanks_as_null      <<- blanks_as_null
            test.idf     <<- test.idf
            t0           <<- as.numeric(Sys.time())
            t00          <<- .self$t0
            attempts     <<- 0
            max_attempts <<- 5
            transaction  <<- FALSE
            operation    <<- operation

            pgtypes    <<- read.csv(system.file("pgtypes",
                                                package = "DelightfulFunctions"))

            if ( !is.null(max.dec)) max.dec <<- max.dec
            if ( !is.null(index.clause)) index.clause <<- index.clause

            if ( !is.null(col.types)) {
                names(col.types) <- .self$clean_names(names(col.types))
                col.types <<- as.list(col.types)
            }
            if ( !is.null(define.args)) {
                define.args <<- as.list(define.args)
            }
            if (operation != 'unload' & !test.idf) {
                .self$fetch_types()
            }

            names(data) <- .self$clean_names(names(data))
            data <<- data.frame(data)
        },

        clean_names = function(nms) {
            gsub("\\.","_",tolower(nms))
        },

        handle_opts = function() {
            # sets required options. preserves original values and resets on exit
            opts       <- list(scipen = 100, stringsAsFactors = FALSE)
            reset.opts <- lapply(names(opts), getOption)
            names(reset.opts) <- names(opts)

            do.call(options, opts)
            reset.opts <<- reset.opts
        },

        handle_conn = function(conn) {
            if (inherits(conn, 'PostgreSQLConnection')) {
                conn <- list(con = conn)
            } else if (inherits(conn, 'db_conn')) {
                conn <- conn$connection
            }

            vers <- dbGetQuery(conn$con, "SELECT version()")[[1]][1]

            if (grepl('redshift', tolower(vers))) {
                conn_type <<- 'redshift'
            } else {
                conn_type <<- 'vanilla'
            }

            conn <<- list(conn)
        },

        finalize = function() {
            if (length(.self$reset.opts)) {
                do.call(options, .self$reset.opts)
            }
            if (.self$transaction) {
                suppressMessages(.self$rollback())
            }
        },

        s3_init = function(aws.creds.path) {
            # aws.creds init for s3 operations
            cred.names <- c("aws_access_key_id","aws_secret_access_key")


            # check env vars first..
            env_vars <- as.list(Sys.getenv())[c(cred.names, toupper(cred.names))]
            env_vars <- env_vars[ !unlist(lapply(env_vars, is.null))]
            names(env_vars) <- tolower(names(env_vars))

            # if a path is specified, override env vars
            if (is.null(aws.creds.path)) {
                if (all(cred.names %in% names(env_vars))) {
                    message('  > Reading AWS credentials from environment variables..')
                    aws.creds <<- env_vars
                    return(invisible())
                } else {
                    aws.creds.path <- "~/creds.json"
                }
            }

            if ( !file.exists(aws.creds.path)) {
                stop(sprintf("AWS Creds file '%s' not found", aws.creds.path))
            }

            message(sprintf("  > Reading AWS credentials from file: '%s'", aws.creds.path))

            aws.creds <- as.list(jsonlite::fromJSON(aws.creds.path))[
                c(cred.names, toupper(cred.names))]
            aws.creds <- aws.creds[ !unlist(lapply(aws.creds, is.null))]
            names(aws.creds) <- tolower(names(aws.creds))

            if ( !all(cred.names %in% names(aws.creds))) {
                stop(sprintf("AWS credentials file must contain values: '%s'",
                             paste(cred.names, collapse = "', '")))
            }
            aws.creds <<- aws.creds
        },

        psql_init = function(aws.creds.path) {
            pgp.path <- path.expand("~/.pgpass")

            if (is.null(aws.creds.path)) aws.creds.path <- "~/creds.json"

            if ( !file.exists(aws.creds.path)) {
                stop(sprintf("Credentials file '%s' not found", aws.creds.path))
            }

            pw <- as.list(jsonlite::fromJSON(aws.creds.path))$ods$password

            if ( !length(pw)) {
                stop("Credentials must contain a value for 'password' in sublist 'ods'")
            }

            if (file.exists(pgp.path)) {
                pgp <- readLines(pgp.path)
            } else {
                pgp <- character(0)
            }

            conn.info <- RPostgreSQL::postgresqlConnectionInfo(.self$conn[[1]]$con)

            aws.creds <<- list(
                instance_name = conn.info$host,
                port          = conn.info$port,
                username      = conn.info$user,
                database      = conn.info$dbname
            )

            if ( !length(pgp) || !grepl(.self$aws.creds$instance_name, pgp, fixed = T)) {
                pgp <- c(
                    paste(sep = ":",
                          .self$aws.creds$instance_name,
                          .self$aws.creds$port,
                          .self$aws.creds$database,
                          .self$aws.creds$username,
                          pw),
                    pgp)

                message("Writing pgpass file with provided credentials")
                writeLines(pgp, pgp.path)
                system(paste("chmod 0600", pgp.path))
            } else {
                message("Using existing pgpass file")
            }
        },

        ##################################################
        ## UTILITY METHODS ##############################
        #################################################

        na.conv = function(x, to='') {
            x[x %in% c(NA,NaN,Inf,-Inf)] <- to
            return(x)
        },

        match_type = function(x, from = "R")
        {
            res <- .self$pgtypes[, which(names(.self$pgtypes) != from)][
                match(x, .self$pgtypes[[from]])
                ]

            res <- res[ !is.na(res)]

            if ( !length(res)) res <- x

            return(res)
        },

        dat_class = function(x) {
            gsub(',','',toString(.self$match_type(class(x))))
        },

        conv.func = function(udt_name) {
            func <- .self$match_type(gsub("[^a-z]","",udt_name), from = "SQL")

            tryCatch(match.fun(paste0("as.",func)),
                     error = function(...) return(as.character))
        },

        tab = function(table_name = .self$table_name) {
            # splits schema from table name
            strsplit(table_name,"\\.")[[1]]
        },

        temp_name = function() {
            # creates temp table name for insert_failsafe() using orig table schema
            paste(c(.self$tab()[1], '.temp_', sample(c(letters,0:9),10, replace = T)),
                  collapse = '')
        },

        status_msg = function(msg, subtractor = .self$t0) {
            # produces annoying messages at various points in execution
            if ( !.self$quietly) {
                secs <- round(as.numeric(Sys.time()) - subtractor)
                message(sprintf(paste(msg, "(%d seconds)"), secs))
            }
            t0 <<- as.numeric(Sys.time())
        },

        nchari = function(x) {
            res <- stri_length(x)
            res[is.na(res)] <- 0

            return(res)
        },

        varLen = function(x) {
            unlist(lapply(x, function(X) { ceiling(X / 5) * 10 } ))
        },

        maxChar = function() {
            ifelse(.self$conn_type == 'redshift',
                   'varchar(max)',
                   'text')
        },

        dbTryQuery = function(statement) {
            tryCatch( {
                dbSendQuery(conn = .self$conn[[1]]$con, statement = statement)
            }, error = function(e) {
                warning("DBI error encountered!", immediate. = TRUE, call. = FALSE)
                .self$rollback()
                stop(e)
            })
        },

        ##################################################
        ## DEFINITION METHODS ############################
        #################################################


        get_cols = function(table_name = .self$table_name) {
            if (inherits(.self$conn[[1]], 'src_postgres')) {
                tbl. <- dplyr::tbl(.self$conn[[1]],
                            dplyr::sql(paste("SELECT * FROM", table_name)))

                if ('ops' %in% names(tbl.)) {
                    cols <- tbl.$ops$vars
                } else {
                    cols <- tbl.$query$vars()
                }
            } else {
                message('Non-dplyr connection used. Fetching column information...')
                cols <- dbGetQuery(.self$conn[[1]]$con, sprintf(
                    "SELECT column_name FROM information_schema.columns
                     WHERE table_schema = '%s' and table_name = '%s'
                     ORDER BY ordinal_position",
                    .self$tab()[1], .self$tab()[2]
                ))[[1]]
                .self$status_msg('COLUMN INFO RETRIEVED')
            }


            return(cols)
        },

        fetch_types = function() {
            # Use data types from redshift if table exists
            if (DBI::dbExistsTable(conn = .self$conn[[1]]$con,
                                   name = c(.self$tab()[1],.self$tab()[2]))) {
                types <- data.frame(col = .self$get_cols())
                types$pos <- 1:nrow(types)
            } else {
                types <- data.frame()
            }
            types <<- types
        },

        table_check = function() {
            if ( !.self$redefine & nrow(.self$types) & !.self$test.idf) {
                stop(sprintf(
                    "Table %s already exists! Set redefine = TRUE to drop and redefine",
                    .self$table_name))
            } else {
                return(TRUE)
            }
        },

        define = function() {
            .self$table_check()

            # Create IDF
            if (.self$lazy.cols) {
                .self$define_lazy()
            } else {
                .self$define_normal()
            }
            .self$status_msg("DATATYPES DONE")
            if (.self$test.idf) {
                return(.self$idf)
            }
        },

        create = function() {

            chk <- try(.self$table_check(), silent = TRUE)
            if (inherits(chk, 'try-error')) {
                warning("Table already exists; not creating.", immediate. = TRUE)
                return(NULL)
            }

            statement <- sprintf(
                "CREATE TABLE %s ( %s )",
                .self$table_name,
                toString(c(.self$idf$sql, .self$define.args))
            )

            .self$begin()

            if (.self$conn_type == 'redshift' && length(.self$index.clause)) {
                statement <- paste(statement, toString(.self$index.clause))
            }

            if (.self$redefine & nrow(.self$types)) {
                .self$dbTryQuery(paste("DROP TABLE",.self$table_name))
            }

            if ( !.self$quietly | length(.self$define.args))  {
                message(paste("Creation statement:\n ", statement))
            }

            .self$dbTryQuery(statement)

            if (.self$operation == 'define') {
                .self$commit()
            }
            .self$status_msg("TABLE CREATED")
        },

        define_lazy = function() {
            idf <- data.frame(
                col  = names(data),
                type = unlist(lapply(names(data), function(x) {
                    if (length(.self$col.types) && x %in% names(.self$col.types)) {
                        message('  >  Using user-defined field specification for: ', x)
                        return(.self$col.types[[x]])
                    } else {
                        return(.self$dat_class(data[[x]]))
                    }
                }))
            )

            idf$type <- ifelse(idf$type %in% c('int','float'),
                               paste0(idf$type, '8'),
                               ifelse(idf$type == 'varchar',
                                      .self$maxChar(),
                                      idf$type))
            idf$sql <- paste(idf$col, idf$type)

            idf <<- data.frame(idf)
        },

        define_normal = function() {
            data[, ] <<- lapply(names(data), function(x) {
                if (grepl("factor", dat_class(data[, x]))) {
                    as.character(data[, x])
                } else {
                    data[, x]
                }
            })

            idf <- bind_rows(lapply(names(data), function(x) {

                if (length(.self$col.types) && x %in% names(.self$col.types)) {
                    message('  >  Using user-defined field specification for: ', x)
                    res <- data.frame(
                        stringsAsFactors = F,
                        col = x,
                        maxval = as.numeric(NA),
                        wideval = '',
                        type = .self$col.types[[x]]
                    )
                    return(res)
                }

                unx <- unique(data[, x])

                res <- data.frame(
                    stringsAsFactors = F,
                    col = x,
                    maxval = if (grepl('float|int', dat_class(unx))) {
                                    suppressWarnings(max(abs(unx), na.rm=T))
                            } else {
                                NA
                            },
                    wideval = as.character(unx[which.max(nchari(unx))]),
                    type = if (any(is.nan(unx)) | any(is.infinite(unx))) {
                                'float4'
                            } else if (grepl('float', dat_class(unx)) &&
                                       all.equal(as.integer(unx), unx) == TRUE) {
                                'int'
                            } else {
                                dat_class(unx)
                            }
                )
                return(res)
            }))

            idf$width <- nchari(idf$wideval)
            idf$type  <- ifelse(idf$type == 'int',
                                ifelse(as.numeric(idf$maxval) >= 2^31,
                                       'int8',
                                       'int4'),
                         ifelse(idf$type == 'float',
                                'float8',
                         ifelse(idf$type == 'varchar',
                                ifelse(idf$width == 0 | idf$width > 255,
                                    .self$maxChar(),
                                    sprintf("varchar(%s)",
                                            .self$varLen(idf$width)) ),
                                idf$type)))
            idf$sql <- paste(idf$col, idf$type)

            idf <<- data.frame(idf)
        },

        ##################################################
        ## COMPATIBILITY CHECK ##########################
        #################################################


        check_new = function(ignore.cols) {
            check <- data.frame(col = names(data),
                                type = sapply(data, .self$dat_class))
            check$type <- ifelse(grepl('factor', check$type),
                                 'varchar',
                                 check$type)

            check <- merge(check, .self$types, by = "col", all.x = T)

            if (length(ignore.cols)) {
                message("Omitting existing table columns from check: ",
                        toString(ignore.cols))
                check <- check[ !check$col %in% ignore.cols, ]
            }

            # If table/data names don't match, halt execution
            if (any(is.na(check$pos)) | nrow(types) > nrow(check)) {
                msg <- ""
                nt  <- paste(check$col[is.na(check$pos)], collapse=", ")
                nd  <- paste(types$col[ !types$col %in% check$col],
                             collapse=", ")
                if (nchar(nd)) {
                    msg <- paste("\nMissing in data: ", nd, msg, sep = "\n")
                }
                if (nchar(nt)) {
                    msg <- paste("\nMissing in table: ", nt, msg, sep = "\n")
                }
                stop(paste("\nColumn names do not match",
                           "(Alter data or set redefine = TRUE to rebuild table)\n",
                           msg,sep="\n"))
            }

            # Re-arrange data to match column order in table
            data <<- data[, types$col]

            # Add datatype to types
            types <<- check

            .self$status_msg("CHECK DONE")
            return(TRUE)
        },


        ##################################################
        ## INSERTION UTILITY METHODS ####################
        #################################################

        begin = function() {
            if ( !.self$transaction) {
                message(" Beginning transaction...")
                dbGetQuery(.self$conn[[1]]$con, "BEGIN TRANSACTION")
                transaction <<- TRUE
            }
        },
        rollback = function() {
            message(" Rolling back changes...")
            dbGetQuery(.self$conn[[1]]$con, "ROLLBACK")
            transaction <<- FALSE
        },
        commit = function() {
            message(" Committing...")
            dbGetQuery(.self$conn[[1]]$con, "COMMIT")
            transaction <<- FALSE
        },

        get_datatypes = function(keep) {
            if ( !nrow(.self$types) | .self$redefine | .self$test.idf) {
                # Keep existing table data, if specified
                if (nrow(.self$types) & keep & !.self$test.idf) {
                    .self$fetch_all(.self$table_name)
                }
                .self$define()
            } else {
                idf <<- .self$types
            }
        },

        fetch_all = function(table_name, failsafe.mode=FALSE) {
            if ('dplyr' %in% row.names(installed.packages())) {
                bind_rows <- dplyr::bind_rows
            }

            # Use unload here?
            old.data <- dbGetQuery(.self$conn[[1]]$con,
                                   paste("SELECT * FROM", table_name))

            if (failsafe.mode) {
                data[, ] <<- lapply(names(data), function(col) {
                    type      <- .self$idf[match(col, .self$idf$col), "type"]
                    conv_func <- .self$conv.func(type)

                    if (type == 'date') {
                        conv_func(ifelse(data[, col] == "", NA, data[, col]))
                    } else {
                        conv_func(data[, col])
                    }

                })
            }

            data <<- data.frame(bind_rows(old.data, data))

            .self$status_msg("EXISTING DATA FETCHED")
        },

        delete_data = function() {
            # run if overwrite = TRUE
            if ( !.self$overwrite & !.self$truncate) {
                return(NULL)
            }
            if (.self$truncate) {
                del.statement <- paste("TRUNCATE", .self$table_name)
                message("Deleting all records from table")
            } else {
                del.params    <- ifelse( !nchar(.self$del.params), "1 = 1",
                                         gsub("^where ","", .self$del.params,
                                              ignore.case = T))
                del.statement <- sprintf("DELETE FROM %s WHERE %s",
                                         .self$table_name, .self$del.params)
                message(sprintf("Deleting these records from table: \n  '%s'",
                                .self$del.params))
            }

            .self$dbTryQuery(del.statement)

            .self$status_msg("DATA DELETED")
        },

        conform_all = function(ignore.cols) {
            # -Conforms data to types defined in idf
            # -Cleans bad chars; changes NA to NULL
            to <- ifelse(.self$upload.type == 'vanilla_copy', NA, '')

            data[, ] <<- lapply(names(data), function(col) {
                dtype <- gsub("[^[:alpha:]]", "",
                              .self$idf[match(col, .self$idf$col), "type"] )

                confunc <- switch(dtype,
                                  "bool"    = function(x) tolower(as.character(x)),
                                  "float"   = function(x) x,
                                  "int"     = function(x) x,
                                  function(x) {
                                      stri_replace_all_fixed(
                                          stri_replace_all_fixed(
                                              as.character(x),
                                              .self$delimiter, ''),
                                          '\n','')
                                  } )

                match_df <- data.frame(to_match = unique(data[, col]) )
                match_df$conformed <- na.conv(x = confunc(match_df$to_match),
                                              to = to)

                return(match_df$conformed[match(data[, col], match_df$to_match)])
            } )

            if (length(ignore.cols) && any(ignore.cols %in% names(data))) {
                message("  >  Ignoring insertion data columns: ", toString(ignore.cols))
                data <<- data[, !names(data) %in% ignore.cols]
            }
            .self$status_msg("DATA CONFORMED")
        },

        stringify = function(data) {

            if ('tidyr' %in% row.names(installed.packages())) {
                data <- unite_(data, col = "sql", names(data), sep = "','")
            } else {
                data$sql <- unlist(lapply(1:nrow(data), function(i) {
                    paste(data[i,], collapse = "','")
                }))
            }

            data$sql <- paste0("'", data$sql, "'")
            data$sql <- gsub("''", "NULL", data$sql)

            return(data$sql)
        },

        opt_size = function() {
            max.size <- 2^24 # (16.7 Mb)
            probs    <- seq(.925, 1, by=.025)

            for (p in probs) {
                max.bpr  <- as.numeric(stats::quantile(unlist(lapply(
                    1:(nrow(data)*.001), function(x) {
                        nchar(.self$stringify(data[sample(nrow(data),1),])
                              ,"bytes") + 2    # size of row string plus '(),'
                    } )), probs = p))

                chunk.size <- trunc(max.size / max.bpr)

                if (chunk.size >= nrow(data)) {
                    chunk.size = nrow(data)
                }

                max.chunk  <- sum(nchar(.self$stringify(
                    data[sample(nrow(data), chunk.size),]), "bytes"))

                if (max.chunk <= max.size * .97) {
                    break
                }


            }
            .self$status_msg("CHUNKS DONE")
            return(chunk.size)
        },

        alter = function(change_cols) {

            col_vec  <- as.character(.self$types$col)
            change_cols <- change_cols[names(change_cols) %in% col_vec]

            if (.self$conn_type == 'redshift') {
                tmp_name <- .self$temp_name()

                for (colname in names(change_cols)) {
                    if (colname %in% col_vec) {
                        col_vec[col_vec == colname] <- sprintf("cast(%s as %s)",
                                                               colname,
                                                               change_cols[[colname]])
                    }
                }
                statement <- sprintf(
                    "ALTER TABLE %1$s RENAME TO %2$s;
                    CREATE TABLE %1$s AS (
                        SELECT %4$s FROM %3$s
                    );
                    DROP TABLE %3$s",
                    .self$table_name,
                    .self$tab(tmp_name)[2],
                    tmp_name,
                    toString(col_vec)
                )
            } else {
                alter_cols <- sprintf("ALTER COLUMN %s TYPE %s",
                                  names(change_cols), change_cols)

                statement <- sprintf(
                    "ALTER TABLE %1$s %2$s;",
                    .self$table_name,
                    toString(alter_cols)
                )
            }

            message("Altering table : \n\t", statement)

            .self$dbTryQuery(statement)

            msg <- paste(collapse = "\n",
                         c("Table definition updated:",
                           sprintf("   > '%s' to '%s'",
                                   names(change_cols), change_cols)) )
            message(msg)
        },

        check_res = function(ins_res) {
            if (inherits(ins_res,"error")) {
                warning(call. = F, immediate. = T,
                        sprintf("LOAD ERROR:\n\t%s\n  > Retrying...",
                                ins_res$message))
                .self$rollback()

                if (.self$attempts >= .self$max_attempts) {
                    stop("Terminating (max retries reached)")
                }
                if (grepl("stl_load_errors|value too long|out of range",ins_res)) {
                    message(sprintf("     (Retry attempt %s of %s)",
                                    .self$attempts, .self$max_attempts))
                    .self$insert_failsafe(err_msg = ins_res$message)
                } else {
                    # Make only one additional attempt for non-STL errors
                    attempts <<- .self$max_attempts
                    .self$begin()
                    .self$create()
                    .self$delete_data()
                    ins_res <- .self$insert_()

                    if (inherits(ins_res, 'error')) {
                        .self$rollback()
                        stop(ins_res)
                    }
                }
            } else {
                .self$commit()
            }
        },

        analyze = function() {
            # Analyze
            tryCatch({
                dbSendQuery(.self$conn[[1]]$con, paste("ANALYZE", .self$table_name))
            },error = function(e) {
                msg <- ifelse(grepl("owner can analyze",e),
                              "You are not the table owner",
                              e$message)
                warning(sprintf("ANALYZE failed - %s",msg), call. = F, immediate. = T)
            })

            .self$status_msg("TABLE ANALYZED")
        },

        grant_permissions = function() {
            if ( !length(.self$perms) || !nchar(.self$perms[[1]])) {
                return(NULL)
            }
            if (is.null(names(.self$perms)) && .self$perms == 'default') {
                perm.list <- list(data_science_power_user = "ALL",
                                  sf_data_analysts = "SELECT")
                if (.self$conn_type == 'redshift') {
                    names(perm.list)[1] <- 'investment_analysts'
                }
            } else {
                perm.list <- .self$perms
            }

            perm.statement <- sprintf("GRANT %s ON %s TO GROUP %s",
                                      perm.list, .self$table_name, names(perm.list))
            tryCatch( {
                dbSendQuery(.self$conn[[1]]$con,
                            paste(perm.statement, collapse = "; "))
            }, error = function(e) {
                warning(call. = F, immediate. = T,
                        "Permission grants failed! \n\t", geterrmessage())
            })
            return(invisible())
        },

        table_statement = function() {
            sprintf("%s (%s)", .self$table_name, toString(names(data)))
        },

        ##################################################
        ## INSERTION ERROR UTILITY METHODS ##############
        ################################################

        fetch_stl = function() {
            message("Getting stl_load_errors..")
            dbGetQuery(.self$conn[[1]]$con, "select * from stl_load_errors")
        },

        process_stl = function(stl) {
            clean_stl <- function(x) { gsub(' {1,}$', '', x) }

            stl <- stl[stl$starttime == max(stl$starttime),]
            stl$raw_field_value <- clean_stl(stl$raw_field_value)
            stl$colname         <- clean_stl(stl$colname)

            func <- switch(
                as.character(stl$err_code),
                '1204' = function(stl)
                {
                    # string length > def length
                    return(.self$resize_char(stl))
                },
                '1207' = function(stl)
                {
                    if (grepl(2^31, stl$err_reason)) {
                        # int4 too large
                        res <- setNames('int8', stl$colname)
                        return(res)
                    } else {
                        stop("Unhandled STL error: ", stl$err_reason)
                    }
                },
                function (stl)
                {
                    stop("Unknown STL error: ", stl$err_code)
                }
            )
            return(func(stl))
        },

        resize_char = function(err_list) {
            width <- nchar(err_list$raw_field_value)
            res   <- setNames(ifelse(width > 255,
                                     .self$maxChar(),
                                     sprintf("varchar(%s)",
                                             .self$varLen(width)) ),
                              err_list$colname)
            return(res)
        },

        process_err_msg = function(err_msg) {
            r <- "(?:CONTEXT.*column )([^: ]+)(?:: \")(.*)(?:\"\n)"
            m <- lapply(attributes(regexpr(perl = TRUE, r, err_msg))[
                c('capture.start','capture.length')
            ], as.integer)

            err_list <- setNames(
                lapply(1:length(m[[1]]), function(i) {
                    substr(err_msg, m[[1]][i], m[[1]][i] + m[[2]][i] - 1)
                }),
                c('colname','raw_field_value')
            )

            if (grepl("value too long", err_msg)) {
                res <- resize_char(err_list)
            } else if (grepl("out of range for type int", err_msg)) {
                res <- setNames('int8', err_list$colname)
            } else {
                stop("Unknown error. No parser defined.")
            }

            return(res)
        },

        insert_failsafe = function(err_msg) {
            if (.self$conn_type == 'redshift') {
                stl <- .self$fetch_stl()
                if ( !nrow(stl)) {
                    message("    No rows found; retrying..")
                    Sys.sleep(2)
                    stl <- .self$fetch_stl()
                }
                message("  > Parsing STL load error...")
                change_cols <- process_stl(stl)
            } else {
                message("  > Attempting to parse DB driver error message...")
                change_cols <- process_err_msg(err_msg)
            }
            .self$begin()

            .self$alter(change_cols)
            .self$delete_data()

            ins_res <- .self$insert_()

            .self$check_res(ins_res)
        },

        insert_failsafe_old = function() {
            orig_name   <- .self$table_name
            table_name <<- .self$temp_name()
            types      <<- data.frame()

            .self$fetch_all(orig_name, failsafe.mode = TRUE)

            .self$get_datatypes(FALSE)
            .self$conform_all()

            ins_res <- .self$insert_()

            if (inherits(ins_res,"error")) {
                stop(sprintf("Terminating.\n\t%s", ins_res))
            }

            dbSendQuery(.self$conn[[1]]$con,
                        sprintf("DROP TABLE %s;
                            ALTER TABLE %s RENAME TO %s",
                                orig_name,
                                .self$table_name, .self$tab(orig_name)[2]))

            table_name <<- orig_name
        },


        ##################################################
        ## INSERTION METHODS ############################
        #################################################


        insert = function(upload.type,
                          keep        = FALSE,
                          overwrite   = FALSE,
                          del.params  = '',
                          truncate    = FALSE,
                          aws.creds   = NULL,
                          analyze     = TRUE,
                          ignore.cols = NULL) {
            # param check
            if (overwrite & !nchar(del.params)) {
                stop(paste("Overwrite = TRUE, but no parameters given.\n ",
                           "Set parameters with del.params"))
            } else if ( !overwrite & nchar(del.params)) {
                stop(paste(
                    "Value detected for del.params..\n  Please explicitly",
                    "declare overwrite = TRUE to delete data from table"))
            }

            overwrite  <<- overwrite
            del.params <<- del.params
            truncate   <<- truncate

            if (upload.type == 'copy') {
                delimiter   <<- '`'
                upload.type <<- ifelse(.self$conn_type == 'vanilla',
                                       'vanilla_copy',
                                       's3_copy')
            } else {
                delimiter   <<- "'"
                upload.type <<- upload.type
            }

            chk <- TRUE

            # initialize creds
            switch(.self$upload.type,
                   "s3_copy"  = .self$s3_init(aws.creds)
                   # ,"psql_copy" = .self$psql_init(aws.creds) # only run if using psql
            )

            # check new data
            if (nrow(.self$types) & !.self$redefine) {
                chk <- .self$check_new(ignore.cols)
            }

            # determine IDF
            .self$get_datatypes(keep = keep)

            if (.self$test.idf) {
                return(.self$idf)
            }

            # conform data per datatype defined in idf
            .self$conform_all(ignore.cols)

            # start transaction
            .self$begin()

            # create/drop table if necessary
            suppressWarnings(.self$create())

            # delete if necessary
            .self$delete_data()

            # do the thing
            ins_res <- .self$insert_()

            .self$check_res(ins_res)

            if (.self$conn_type != 'redshift' && length(.self$index.clause)) {
                statement <- paste("CREATE INDEX on",
                                   .self$table_name, .self$index.clause)
                message(paste("Index statement:\n ",statement))
                dbSendQuery(.self$conn[[1]]$con, statement)
                .self$status_msg("INDEX CREATED")
            }

            if (analyze & !.self$redefine) {
                .self$analyze()
            }
            .self$grant_permissions()
            .self$status_msg("INSERTION COMPLETE", .self$t00)
        },

        insert_ = function() {
            attempts <<- .self$attempts + 1

            tryCatch( {
                switch(.self$upload.type,
                       "s3_copy"      = .self$insert_s3(),
                       "vanilla_copy" = .self$insert_vanilla(),
                       .self$insert_bulk()
                )
            },
            error = function(e) {
                return(e)
            }
            )
        },

        insert_bulk = function() {
            chunk.size <- .self$opt_size()

            rseq <- c(seq(1,nrow(data),chunk.size), nrow(data))
            r    <- 2

            message(sprintf("Uploading data to %s (%d chunk(s) of ~%d rows)",
                            .self$table_name, length(rseq)-1, chunk.size))

            while (nrow(data)) {
                pgres <- tryCatch( {
                    chunk.rows <- ifelse(nrow(data) < chunk.size, nrow(data),chunk.size)
                    dbSendQuery(.self$conn[[1]]$con,
                                paste0("INSERT INTO ",table_name," VALUES ",
                                       paste0(paste("(",.self$stringify(data[1:chunk.rows, ]),
                                                    sep="",collapse="),"),")")))
                }, error = function(e) { return(e) } )

                if (inherits(pgres,"error")) {
                    if ( !grepl("too large", pgres)) {
                        stop(sprintf("Terminating.\n\t%s", pgres))
                    }
                    warning(sprintf("Chunk size (%d) too large. Decreasing...",
                                    chunk.size), call. = F, immediate. = T)
                    chunk.size <- round(chunk.size * .95)
                    rseq       <- c(rseq[rseq < rseq[r-1]],
                                    seq(rseq[r-1], nrow(data), chunk.size),
                                    nrow(data))
                } else {
                    if ( !.self$quietly) {
                        message(sprintf("Chunk %d of %d inserted",r-1, length(rseq)-1))
                    } else if (r == length(rseq)) {
                        message("All chunks inserted successfully")
                    }
                    r <- r + 1
                    data <<- data[-c(1:chunk.rows), ]
                }
            }
        },

        insert_s3 = function() {
            local_path <- tempfile(fileext = ".csv")
            s3_path    <- sprintf("ds/redshift_upload/%s.%s.csv.gz",
                                  table_name,
                                  format(Sys.time(),format = "%Y-%m-%dT%H-%M-%S"))

            fwrite(x    = data,
                   file = local_path,
                   sep  = .self$delimiter,
                   col.names = F, quote = F)

            system(sprintf("gzip -f '%s'", local_path))
            local_path <- paste0(local_path, '.gz')
            .self$status_msg("LOCAL TABLE WRITTEN")

            s3_result <- tryCatch(
                {
                    put_s3_object(file    = local_path,
                                  bucket = .self$bucket,
                                  s3_path = s3_path,
                                  key     = .self$aws.creds$aws_access_key_id,
                                  secret  = .self$aws.creds$aws_secret_access_key)
                },
                error = function(e) return(e)
            )

            if (inherits(s3_result, 'error')) {
                attempts <<- .self$max_attempts
                stop(s3_result)
            } else {
                .self$status_msg("FILE UPLOADED TO S3")

                cq <- sprintf(
                    "COPY %s FROM 's3://%s/%s'
                    CREDENTIALS 'aws_access_key_id=%s;aws_secret_access_key=%s'
                    DELIMITER '%s'
                    GZIP
                    %s
                    ",
                    .self$table_statement(),
                    .self$bucket,
                    s3_path,
                    .self$aws.creds$aws_access_key_id,
                    .self$aws.creds$aws_secret_access_key,
                    .self$delimiter,
                    ifelse(.self$blanks_as_null, "BLANKSASNULL", '')
                )
                dbSendQuery(.self$conn[[1]]$con, cq)
                .self$status_msg("QUERY EXECUTED")
            }

            file.remove(local_path)
        },

        insert_vanilla = function() {
            RPostgreSQL:::postgresqlpqExec(
                con       = .self$conn[[1]]$con,
                statement = sprintf("COPY %s FROM STDIN", .self$table_statement())
            )

            RPostgreSQL:::postgresqlCopyInDataframe(
                con       = .self$conn[[1]]$con,
                dataframe = .self$data
            )

            res <- tryCatch(
                {
                    RPostgreSQL:::postgresqlgetResult(.self$conn[[1]]$con)
                },
                error = function(e) return(e)
            )

            if (inherits(res, 'error')) {
                stop(res)
            } else {
                dbClearResult(res)
                .self$status_msg("QUERY EXECUTED")
            }
        },

        insert_psql = function() {
            local_path <- tempfile(fileext = ".csv")

            write.table(x    = data,
                        file = local_path,
                        sep  = .self$delimiter,
                        row.names = F, col.names = F, quote = F)
            .self$status_msg("LOCAL TABLE WRITTEN")

            cmd <- sprintf("psql -h %s -p %s -U %s -d %s -o /dev/stdout -c %s",
                           .self$aws.creds$instance_name,
                           .self$aws.creds$port,
                           .self$aws.creds$username,
                           .self$aws.creds$database,
                           shQuote(
                               sprintf("\\copy %s from '%s' with (DELIMITER '%s', NULL '')",
                                       .self$table_statement(),
                                       local_path,
                                       .self$delimiter)) )

            exitStatus <- system(cmd)

            if (exitStatus == 0) {
                .self$status_msg("QUERY EXECUTED")
            } else {
                stop("PSQL COPY failed")
            }

            file.remove(local_path)
        },

        ##################################################
        ## UNLOAD METHODS ###############################
        #################################################


        unload = function(aws.creds) {
            .self$s3_init(aws.creds)

            #
            logicol_conv <- function(x) { as.logical(toupper(x)) }

            # prepare filenames, make temp dir
            delimiter <- "`"
            cur_time  <- format(Sys.time(),format = "%Y-%m-%dT%H-%M-%S")

            local_path <- file.path(tempdir(), paste0("sql_unload_", cur_time))
            final_path <- file.path(local_path, 'merged.gz')
            s3_path    <- sprintf("ds/redshift_download/%s.%s",
                                  .self$table_name, cur_time)
            suppressWarnings(dir.create(local_path))

            # Unload doesn't preserve col names; readr works better with explicit types

            cols <- dbGetQuery(
                .self$conn[[1]]$con,
                sprintf("select column_name as col, udt_name
                        from information_schema.columns
                        where table_schema = '%s' and table_name = '%s'
                        order by ordinal_position",
                        .self$tab()[1], .self$tab()[2]) )

            cols$type <- ifelse(grepl('float|numeric|int',cols$udt_name),'d','c')

            logicols <- cols$col[cols$udt_name == "bool"]

            .self$status_msg("FIELD INFO RETRIEVED")

            # Unload

            uq <- sprintf("UNLOAD ('select * from %s') TO 's3://%s/%s'
                          CREDENTIALS 'aws_access_key_id=%s;aws_secret_access_key=%s'
                          DELIMITER '%s' MANIFEST GZIP ALLOWOVERWRITE",
                          .self$table_name,
                          .self$bucket,
                          s3_path,
                          .self$aws.creds$aws_access_key_id,
                          .self$aws.creds$aws_secret_access_key,
                          delimiter)
            dbSendQuery(.self$conn[[1]]$con, uq)

            .self$status_msg("UNLOAD QUERY EXECUTED")

            # Download and combine

            manifest <- jsonlite::fromJSON(rawToChar(
                    get_s3_object(s3_path = paste0(s3_path, 'manifest'),
                                  key = .self$aws.creds$aws_access_key_id,
                                  secret = .self$aws.creds$aws_secret_access_key)
                ))$entries$url

            paths <- unlist(lapply(manifest, function(key) {
                s3_path <- strsplit(key,
                                    paste0(formals(get_s3_object)$bucket,'/'))[[1]][2]
                path <- file.path(local_path, basename(key))
                save_s3_object(s3_path = s3_path,
                               file = path,
                               key = .self$aws.creds$aws_access_key_id,
                               secret = .self$aws.creds$aws_secret_access_key)
                return(path)
            }))

            cmd <- sprintf('cat %s > %s', paste(paths, collapse = ' '), final_path)
            res <- system(cmd)

            if (res) {
                stop('File merge failed.\n  Command attempted: \n', cmd)
            } else {
                file.remove(paths)
            }

            .self$status_msg("FILES RETRIEVED AND MERGED")

            # Read

            if ("readr" %in% rownames(installed.packages())) {
                data <- readr::read_delim(final_path,
                                          delimiter,
                                          col_names = cols$col,
                                          col_types = paste(cols$type,collapse=""))
                data <- data.frame(data)
            } else {
                data <- read.table(final_path,
                                   header = F,
                                   sep = delimiter,
                                   col.names = cols$col)
            }

            .self$status_msg("TABLE READ")

            if (nrow(data)) {
                file.remove(final_path)
                file.remove(local_path)
            }

            for (col in logicols) {
                data[, col] <- logicol_conv(data[, col])
            }

            .self$status_msg("UNLOAD COMPLETE", .self$t00)
            return(data.frame(data))
        }

        #################################################
    )
))
