#' @title Create a Dropbox object
#'
#' @param token_path Path to an RDS containing a valid httr OAuth2 token
#' @param verbose Logical value indicating the user's desire to be annoyed
#'
#' @import httr
#'
#' @export

src_dropbox <- function(token_path = '~/tokens/db_token.Rds',
                        verbose = FALSE,
                        ...)
{
    dropr(token_path = token_path,
          verbose = verbose,
          ...)
}


#' @title Authorize a Dropbox token
#'
#' @param app_key Dropbox app key (dropbox.com/developers/apps)
#' @param app_secret Dropbox app secret (dropbox.com/developers/apps)
#' @param save_loc Location to save the generated token. Default: '~/tokens/db_token.Rds'
#'
#' @import httr
#'
#' @export

dropbox_auth <- function(app_key,
                         app_secret,
                         save_loc = '~/tokens/db_token.Rds')
{
    if (app_key == '' | app_secret == '') {
        stop("You must provide a valid app_key and app_secret..")
    }

    message(
        "!!! NOTICE !!!\n",
        "This function must be executed on your local machine, NOT a remote server,\n",
        " to successfully complete the OAuth exchange..\n",
        "Otherwise, your session will hang here:\n",
        " 'Waiting for authentication in browser...'\n",
        "YOU HAVE BEEN WARNED\n",
        "  - MGMT"
    )

    if ( !'httpuv' %in% row.names(installed.packages())) {
        install.packages('httpuv')
    }
    require(httr)
    require(httpuv)
    ##############################################################

    save_loc <- path.expand(save_loc)

    opt.name <- 'httr_oob_default'
    reset.opts <- setNames(as.list(getOption(opt.name)), opt.name)
    on.exit( {
        do.call(options, reset.opts)
    } )

    do.call(options, setNames(list(FALSE), opt.name))

    tok <- httr::oauth2.0_token(
        endpoint = httr::oauth_endpoint(
            authorize = "https://www.dropbox.com/1/oauth2/authorize",
            access    = "https://api.dropbox.com/1/oauth2/token"
            ),
        app = httr::oauth_app(
            appname = "dropbox",
            key = app_key,
            secret = app_secret
        ),
        cache   = FALSE,
        use_oob = FALSE
    )
    stopifnot(inherits(tok, "Token2.0"))

    if ( !dir.exists(dirname(save_loc))) {
        dir.create(dirname(save_loc))
    }

    message("Writing token to: ", save_loc)
    saveRDS(tok, save_loc)
}
