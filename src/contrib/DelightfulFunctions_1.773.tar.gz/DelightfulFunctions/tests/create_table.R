options(stringsAsFactors = FALSE)
library(mmkit)
library(DelightfulFunctions)

con = mmkit::db_conn('redshift')

df = data.frame(col1 = c('a', 'b', 'c'),
                colb = as.numeric(1:3))

out = sql_insert(data=df, con = con,  table_name = 'mktg.test_dev', redefine = T,
                 bucket='framebridge-ds')
