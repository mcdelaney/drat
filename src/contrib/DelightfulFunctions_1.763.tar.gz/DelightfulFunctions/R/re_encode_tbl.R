#' @title re_encode_tbl
#' @description Redshift supports a variety of compression algorithms for encoding data at rest on disk.
#' By default, redshift will select a compression type during table creation.  Like many things redshift, column
#' encodings cannot be altered once the table is created.  As a result, as a table grows, the compression type chosen
#' initially by redshift may become suboptimal. This utility recalculates the optimal compression type for the target table
#' and copies it's data to a new table with the appropriate encodings, drops the old version, and renames the copy to match
#' the orginal.  You shouldnt need to use this frequently, but should consider it for infrequently redefined tables.
#' @param schema Schema of the table to be re-encoded.
#' @param table Name of the table to be re-encoded.
#' @param sort_key_stmt Sort key clause for the table. Eg: INTERLEAVED SORTKEY(height, weight, ilya).
#' @param con A valid mmkit::db_conn connection to a redshift cluster.
#' @import dplyr
#' @export

re_encode_table <- function(schema, table, sort_key_stmt = '', con) {

    message(sprintf("Re-encoding table %s.%s...", schema, table))

    message('Analyzing optimal compression types for table...')
    compression = con$query("ANALYZE COMPRESSION {{schema}}.{{table}}",
                            schema = schema, table = table)

    if (all(compression$Est_reduction_pct == "0.00")) {
        message('All columns have optimal encoding already...exiting...')
        return(invisible())
    }

    names(compression) = tolower(names(compression))
    columns = con$query("SELECT column_name as column, data_type, character_maximum_length AS char_len
                        FROM information_schema.columns
                        WHERE table_name = '{{table}}'
                            AND table_schema = '{{schema}}'",
                        table = table, schema = schema) %>%
        mutate(data_type = ifelse(!is.na(char_len), paste0(data_type, "(", char_len, ")"), data_type)) %>%
        select(-char_len)

    compression <- left_join(compression, columns)
    compression = compression %>% mutate(stmt = paste(column, data_type, "encode", encoding))

    message('Optimal compression settings found... creating new table and copying data from original...')
    con$send("CREATE TABLE {{schema}}.{{table}}_2
             ({{cols}})
             {{sort_key}}",
             cols = paste0(compression$stmt, collapse = ' , '),
             sort_key = sort_key_stmt, table=table, schema = schema)

    con$send("INSERT INTO {{schema}}.{{table}}_2 SELECT * FROM {{schema}}.{{table}}",
             table = table, schema = schema)

    if (sort_key_stmt != '') {

        message('Sort key set... Running vacuum-reindex....')
        con$send("VACUUM REINDEX {{schema}}.{{table}}_2;", table = table, schema = schema)
    }

    message('Analyzing new table...')
    con$send("ANALYZE {{schema}}.{{table}}_2;", table = table, schema = schema)

    message('Dropping original + Renaming new copy...')
    con$send("ALTER TABLE {{schema}}.{{table}} RENAME TO {{table}}_3;
             ALTER TABLE {{schema}}.{{table}}_2 RENAME TO {{table}};
             DROP TABLE {{schema}}.{{table}}_3",
             table = table, schema = schema)

    message("Re-encoding completed successfully!")
    return(invisible())
}
