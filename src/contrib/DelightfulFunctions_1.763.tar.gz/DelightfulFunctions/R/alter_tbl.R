#' @title alter_tbl
#' @description Call alter_tbl to modify the column type of an existing redshift
#' table.  Eg: you might use alter_tbl to expand the varchar width of column from
#' varchar(25) to varchar(225).
#' @param table Schema of the table to be re-encoded.
#' @param current_col Name of the table to be re-encoded.
#' @param new_col_type Sort key clause for the table. Eg: INTERLEAVED SORTKEY(height, weight, ilya).
#' @param conn A valid mmkit::db_conn connection to a redshift cluster.
#' @export


alter_tbl <- function(table, current_col, new_col_type, conn){
    conn$send("ALTER table {{table}} ADD COLUMN new_col {{new_col_type}};
              UPDATE {{table}} SET new_col = cast({{current_col}} as {{new_col_type}});
              ALTER table {{table}} DROP COLUMN {{current_col}};
              ALTER table {{table}} RENAME COLUMN new_col to {{current_col}}",
              table = table, new_col_type = new_col_type,
              current_col = current_col)
    return("success")
}
