#' @title Save/load an R object to/from an RDS3
#' @param object For \code{saveRDS3}, any R object. For \code{loadRDS3}, an RDS3 raw vector; usually the contents of an AWS GET response
#' @param compress Logical value. If TRUE (default), gzip compression is used.
#' @export

saveRDS3 <- function(object, compress = TRUE) {
    switch(compress + 1, serialize(object, NULL), memCompress(serialize(object,
        NULL), type = "gzip"))
}


#' @rdname saveRDS3
#' @export

loadRDS3 <- function(raw_vec) {
    compressed <- rawToChar(raw_vec[1:2]) == "x\x9c"
    switch(compressed + 1, unserialize(raw_vec), unserialize(memDecompress(raw_vec,
        type = "gzip")))
}


#' @title Create an s3 friendly file path
#' @param ... One or more strings to be combined. Leading/trailing slashes and all white space are removed.
#' @export

build_s3_path <- function(...) {
    paste(gsub('\\s|^/|/$','', c(...)), collapse = '/')
}
