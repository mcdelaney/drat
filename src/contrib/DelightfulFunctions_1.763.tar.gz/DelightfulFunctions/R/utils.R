


bind_rows <- function(...)
{
    dots <- list(...)
    if (is.list(dots[[1]]) && !is.data.frame(dots[[1]]) && !length(dots[-1])) {
        dots <- dots[[1]]
    }

    all.names <- unique(unlist(lapply(dots, names)))

    dots <- lapply(dots, function(df) {
        missing <- all.names[ !all.names %in% names(df)]
        df <- data.frame(df)

        if (length(missing) & nrow(df)) {
            df[, missing] <- NA
        }
        return(df)
    })

    return(do.call(rbind, dots))
}
