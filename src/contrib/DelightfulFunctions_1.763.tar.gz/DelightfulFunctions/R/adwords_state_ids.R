#' @title get_adwords_state_ids
#'
#' @export
#'

adwords_state_ids<-function(){

state_ids<-readRDS(file = paste0(system.file(package="DelightfulFunctions"),
                                 "/adwords_location_id.RDS"))

return(state_ids)
}

