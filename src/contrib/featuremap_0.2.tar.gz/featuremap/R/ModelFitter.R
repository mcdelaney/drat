#' @title ModelFitter
#' 
#' @description Modelfitter simplifies the machine learning model-training 
#' process by automating hyperparam tuning, cross validation, and the cacluation
#' of diagnostic metrics such as variable importance plots. 
#' 
#' @import logging
#' @import xgboost
#'
#' @export

ModelFitter = R6::R6Class(
  classname='ModelFitter',
  
  public=list(
    model_tag = NA,
    model_subtag = NA,
    model_name = NA,
    version = NA,
    log = NA,
    best_cv_eval = NA,
    featuremap = NA,
    eval_metric = NA,
    nrounds = 350,
    nthread = NA, 
    best_params = NA,
    final_model = NA,
    eval_summary = NA,
    data = NA,
    search_params = list(),
    
    initialize=function(featuremap, data, eval_metric, pct_cores=0.25) {
      self$featuremap <- featuremap
      self$model_tag <- featuremap$model_tag
      self$model_subtag <- featuremap$model_subtag
      self$model_name <- featuremap$model_name
      self$nthread <- round(parallel::detectCores()*pct_cores)
      private$get_logger()
      
      if (!eval_metric %in% c("logloss", "mae", "auc")) {
        stop("Eval metric must be one of logloss, mae, or auc!")
      }
      
      self$eval_metric <- eval_metric
      self$data <- data
      
    },
    set_xgb_search_params = function(gamma = seq(0, 1, 0.25), 
                                     max_depth = c(3, 5, 7, 10),
                                     objective = 'binary:logistic', 
                                     subsample = c(0.50, 0.75, 1),
                                     max_delta_step = 0,
                                     min_child_weight = 1,
                                     scale_pos_weight = 1,
                                     colsample_bytree = c(0.50, 0.75, 1),
                                     tree_method="auto") {
      
      self$log$info('Creating hyperparam matrix for tuning...')
      mtx = expand.grid(gamma = gamma,
                        max_depth = max_depth, 
                        objective = objective,
                        subsample = subsample,
                        max_delta_step = max_delta_step,
                        scale_pos_weight = scale_pos_weight,
                        colsample_bytree = colsample_bytree,
                        min_child_weight = min_child_weight,
                        tree_method = tree_method,
                        stringsAsFactors = FALSE)
      
      for (i in 1:nrow(mtx)) {
        self$search_params[[i]] = as.list(mtx[i,])
        
      }
      self$log$info('Total param combinations returned: %d...', 
                    length(self$search_params))
      
    },
    
    find_optimal_params = function(print_every_n = 50, 
                                   early_stopping_rounds = 15, 
                                   metrics = c('logloss', 'auc', 'mae'),
                                   nfold = 4,
                                   stratified = TRUE,
                                   nthread = self$nthread) {
      
      self$log$info("Starting model run for %s", self$model_name)
      counter = 0
      for (i in 1:length(self$search_params)) {
        model_run = NULL
        try({
          self$log$info('Starting job %d of %d', i, length(self$search_params))
          print(t(as.data.frame(self$search_params[[i]])))
          
          model_run = xgb.cv(data = self$data$train_dmtx,
                             nrounds = self$nrounds, 
                             print_every_n = print_every_n,
                             early_stopping_rounds = early_stopping_rounds,
                             metrics = metrics, 
                             nfold = nfold, 
                             nthread = nthread,
                             stratified = stratified,
                             params = self$search_params[[i]])
          
        })
        if (!is.null(model_run)){
          counter = counter + 1
          self$search_params[[counter]] = self$search_params[[i]]
          self$search_params[[counter]][['eval_result']] = model_run
        }
      }
      self$search_params = self$search_params[1:counter]
      
      private$find_best_cv_params()
      
    },
    
    train_final_model = function() {
      
      self$log$info('Training final model...')
      final_model <- xgb.train(data=self$data$train_dmtx, 
                               params = self$best_params, 
                               watchlist = list(train = self$data$train_dmtx, 
                                                test = self$data$test_dmtx),
                               eval_metric = self$eval_metric,
                               nrounds = self$nrounds,
                               nthread = self$nthread,
                               early_stopping_rounds = 15)
      
      self$log$info('Computing variable importance matrix...')
      importance = xgb.importance(model=final_model,
                                  feature_names=as.character(dimnames(self$data$train_x)[[2]])
      )
      eval_output = list(metric = self$best_cv_eval)
      names(eval_output) <- self$eval_metric
      
      xgb.attr(final_model, 'featuremap') <- self$featuremap$export_map()
      xgb.attr(final_model, 'session_id') <- self$featuremap$session_id
      xgb.attr(final_model, 'created_at') <- self$uct_time_char
      xgb.attr(final_model, 'model_tag') <- self$model_tag
      xgb.attr(final_model, 'model_subtag') <- self$model_subtag
      xgb.attr(final_model, 'eval') <- jsonlite::toJSON(eval_output, auto_unbox = TRUE)
      xgb.attr(final_model, 'importance') <- jsonlite::toJSON(importance)
      xgb.attr(final_model, 'best_params') <- jsonlite::toJSON(
        self$best_params[!names(self$best_params) %in% "eval_result"])
      
      self$final_model <- final_model
      
      self$log$info('Model trained successfully!')
      return(invisible())
    },
    importance_plot = function(top_n = 25, rel_to_first = TRUE) {
      
      tryCatch({
        return(xgb.ggplot.importance(self$importance_matrix, top_n = top_n, 
                                     rel_to_first = rel_to_first))
      }, error = function(e) {
        return(xgb.plot.importance(self$importance_matrix, top_n = top_n, 
                                   rel_to_first = rel_to_first))
      })
    }
  ),
  active = list(
    importance_matrix = function() {
      if (all(is.na(self$final_model))) {
        self$log$warn('No model has been created yet!')
        return(invisible())
      }
      
      data.table::as.data.table(
        jsonlite::fromJSON(xgb.attr(self$final_model, 'importance')))
      
    },
    uct_time_char = function() {
      current = Sys.time()
      attr(current, "tzone") <- "UTC"
      gsub("\\s|-|:", "_", as.character(current))
      
    }
  ),
  
  private = list(
    get_logger = function() {
      self$log <- getLogger(sprintf('ModelFitter_%s', self$model_name))
      self$log$addHandler(writeToConsole, level="INFO")
      self$log$info('Initializing ModelFitter for %s', self$model_name)
      
    },
    
    get_eval_summary = function(){
      
      self$log$info('Creating eval log for best iterations at each param set...')
      eval_metric  = paste0('test_', self$eval_metric)
      best_iters = purrr::map_dbl(self$search_params, 
                                  ~.[['eval_result']][['best_iteration']][[1]])
      
      evals = data.frame(
        test_mean = purrr::map2_dbl(self$search_params, best_iters, 
                                    ~.x[['eval_result']][['evaluation_log']][.y, ][[paste0(eval_metric, '_mean')]]),
        test_std = purrr::map2_dbl(self$search_params, best_iters, 
                                   ~.x[['eval_result']][['evaluation_log']][.y, ][[paste0(eval_metric, '_std')]]))
      
      switch(self$eval_metric, 
             'auc' = {
               evals$is_best <- evals$test_mean == max(evals$test_mean)
             },
             'logloss' = {
               evals$is_best <- evals$test_mean == min(evals$test_mean)
             },
             'mae' = {
               evals$is_best <- evals$test_mean == min(evals$test_mean)
               
             }
      )
      
      self$eval_summary <- evals
      
    },
    find_best_cv_params = function() {
      
      self$log$info('Finding best params for %s...', self$eval_metric)
      private$get_eval_summary()
      
      self$best_params <- self$search_params[[which.max(self$eval_summary$is_best)]]
      self$best_cv_eval <- self$eval_summary$test_mean[[which.max(self$eval_summary$is_best)]]
      
      self$log$info('Best params found:')
      print(unlist(self$best_params[1:5]))
      return(invisible())
      
    }
    
  )
)
