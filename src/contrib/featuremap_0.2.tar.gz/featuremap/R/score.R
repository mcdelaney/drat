#' @title score
#' @description Method for scoring data given a model and featuremap.

score <- function(fmap, model, data) {
  # Encode new data per the featuremap definition, and return predictions.
  if (!'xgb.DMatrix' %in% class(data)) {
    data = fmap$encode_data_speed(data = data)
    data = xgboost::xgb.DMatrix(data, missing = fmap$missing)
    
  }
  
  pred = predict(model, newdata = data)
  return(pred)
  
}