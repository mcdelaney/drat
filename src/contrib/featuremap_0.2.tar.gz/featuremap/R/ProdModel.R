#' @title ProdModel
#'
#' @description Score new data with existing models. By default, exports models to s3. 
#' If export_models(s3=FALSE), model will be saved to current working directory.
#'
#' @import logging
#' @import xgboost
#' @import DBI
#'
#' @export

ProdModel = R6::R6Class(
  classname='ProdModel',
  
  public=list(
    model_tag = NA,
    model_subtag = NA,
    version = NA,
    log = NA,
    featuremap = NA,
    session_id = NA,
    lag_info = NA,
    eval = NA,
    model = NA,
    conn = NA,
    bucket = NA,
    base_modelstore="model_store",
    deployment_table = c("ds", "model_deployment"),
    created_at = NA,
    best_params = NA,
    initialize=function(model_tag, model_subtag = NA, version = NA, conn = NA, 
                        bucket='corp-bi') {
      self$model_tag <- tolower(model_tag)
      self$model_subtag <- tolower(model_subtag)
      self$version <- tolower(version)
      self$bucket <- bucket
      private$get_logger()
      self$conn <- conn
    },
    import_model = function(s3=TRUE, local_model_store = '') {
      
      tryCatch({
        
        if (s3) {
          if (class(self$conn) != "db_conn"){
            stop("No database connection provided")
          }
          model_path_s3 <- private$get_s3_location()
          self$log$info('Reading model from s3://%s/%s...', 
                        model_path_s3$s3_bucket, model_path_s3$s3_object)
          
          self$model <- xgb.load(aws.s3::get_object(model_path_s3$s3_object, model_path_s3$s3_bucket))
          
        }else{
          local_path = ifelse(local_model_store == '', self$model_path,
                              sprintf("%s/%s.xgb", local_model_store, 
                                      self$model_path))
          self$log$info('Reading model from local file: %s...', local_path)
          self$model <- xgb.load(local_path)
          
        }
        
      }, error = function(e) {
        stop("Model file not found; Error message:", e)
      })
      
      private$process_model()
      
    },
    export_model = function(model, lag_info = NA, s3 = TRUE, 
                            local_model_store = "") {
      self$log$info('Starting model export...')
      
      self$model = model
      
      if (!length(lag_info) == 1 && !is.na(lag_info)) {
        self$log$info('Lag entry found...appending as attribute')
        xgb.attr(self$model, 'lag_info') <- jsonlite::toJSON(lag_info)
        
      }else{
        self$log$info('No lag data found...')
        xgb.attr(self$model, 'lag_info') <- jsonlite::toJSON("")
        
      }
      
      private$process_model()
      
      if (s3) {
        if (class(self$conn) != "db_conn"){
          stop("No database connection provided")
        }
        export_path = sprintf("%s/%s.xgb", self$base_modelstore, self$model_path)
        self$log$info('Exporting model s3://%s/%s', self$bucket, export_path)
        
        model_raw = xgb.save.raw(self$model)
        aws.s3::put_object(model_raw, object = export_path, bucket = self$bucket)
        self$add_model_to_db(export_path)
        
      }else{
        export_path = ifelse(local_model_store != '',
                             sprintf('%s/%s.xgb', local_model_store, self$model_path),
                             sprint("%s.xgb", self$model_path))
      
        self$log$info('Exporting model to local file: %s', export_path)
        xgb.save(self$model, export_path)
        
      }
      
      self$log$info('Model export complete...')
      
      return(export_path)
      
    },
    score = function(data) {
      
      loginfo('Scoring data...')
      if (!class(data) == 'xgb.DMatrix') {
        data = self$featuremap$encode_data(data = data, as_matrix = TRUE)
        data = xgb.DMatrix(data, missing=self$featuremap$missing)
        
      }
    
      pred = predict(self$model, newdata = data)
      return(pred)
    
    },
    importance_plot = function(top_n = 25, rel_to_first = TRUE) {
      
      if ('ggplot2' %in% row.names(installed.packages())) {
        xgb.ggplot.importance(self$importance_matrix, top_n = top_n,
                              rel_to_first = rel_to_first)
      
      }else{
        xgb.plot.importance(self$importance_matrix, top_n = top_n,
                            rel_to_first = rel_to_first)
      
      }
    },
    
    add_model_to_db = function(export_path){
      self$log$info("Logging new model")
      new_row <- data.frame(model_tag = self$model_tag,
                            model_subtag = self$model_subtag,
                            version = self$version,
                            s3_bucket = self$bucket,
                            s3_object = export_path,
                            is_active = FALSE,
                            created_date = Sys.time(),
                            eval = self$eval,
                            session_id = self$session_id)
        tryCatch({
          result <- dbWriteTable(self$conn$con, name = self$deployment_table, 
                                 value = new_row, append = TRUE, 
                                  row.names = FALSE)
          

        }, error = function(e) {
          
          result = self$conn$send("INSERT INTO {{schema}}.{{table}}({{cols}})
                                  VALUES ('{{vals}}')",
                                  schema = self$deployment_table[1],
                                  table = self$deployment_table[2], 
                                  cols = paste0(names(new_row), collapse = ','),
                                  vals = paste0(new_row[,], collapse = "','"))
        })
      if (result){
        self$log$info("Model entry added to %s.%s", self$deployment_table[1], self$deployment_table[2])
      } else{
        stop(sprintf("Write to %s.%s failed", self$deployment_table[1], self$deployment_table[2]))
      }
    }
    
  ),
  active = list(
    model_path = function() {
      if (is.na(self$model_subtag)){
        gsub("-|:|\\s", "_", sprintf('%s_%s', self$model_tag, self$version))
      } else{
        gsub("-|:|\\s", "_", sprintf('%s_%s_%s', self$model_tag, self$model_subtag, self$version))
      }
    
    },
    importance_matrix = function() {
      
      if (all(is.na(self$model))) {
        self$log$warn('No model has been created yet!')
        return(invisible())
      
      }
      data.table::as.data.table(
        jsonlite::fromJSON(xgb.attr(self$model, 'importance')))

    }
  ),
  private = list(
    get_logger = function() {
      self$log <- getLogger('ProdModel')
      self$log$addHandler(writeToConsole, level="INFO")
      model_name <- if (is.na(self$model_subtag)){
        self$model_tag
      } else {
        paste(self$model_tag, self$model_subtag, sep = "_")
      }
      self$log$info('Initializing ProdModel for %s', model_name)

    },
    
    get_s3_location = function(){
      self$log$info("Fetching location of active model from database")
      tryCatch({
        query_fmt <- "
        select s3_bucket, s3_object
        from %s.%s
        where model_tag = '%s'
        %s
        and is_active = true
        order by last_activated_date desc"
        query <- sprintf(query_fmt,
                         self$deployment_table[1], self$deployment_table[2], self$model_tag,
                         ifelse(is.na(self$model_subtag), "", sprintf("and model_subtag = '%s'", self$model_subtag)))
        active_model <- self$conn$query(query)
        },
        error = function(e){
          stop("Active model query failed; Query: %s; Error message: %s", query, e)
        }
      )
      if (nrow(active_model) == 0){
        stop(sprintf("No active model found for tag = %s and subtag = %s", self$model_tag, self$model_subtag))
      } else if (nrow(active_model) > 1){
        self$log$warn("Multiple active models found matching tag = %s and subtag = %s; selecting most recently activated",
                      self$model_tag, self$model_subtag)
        active_model <- active_model[1, ]
      }
      self$log$info('Location found = s3://%s/%s...', active_model$s3_bucket, active_model$s3_object)
      return(active_model)
    },
    
    process_model = function(model) {
      self$log$info("Processing model metadata...")
      
      private$validate_model_tag()
      self$eval <- private$parse_eval_params()
      self$best_params <- private$parse_best_model_params()
      self$lag_info <- private$parse_lag_info()
      self$created_at <- private$parse_model_timestamp()
      self$featuremap <- private$parse_featuremap_from_model()
      self$session_id <- private$parse_session_id()
      
      self$log$info('Model processed successfully...')
      
    },
    parse_lag_info = function() {
      if (!"lag_info" %in% names(xgb.attributes(self$model))) {
        return(NA)
        
      }
      self$log$info('Lag info detected...extracting')
      jsonlite::fromJSON(xgb.attr(self$model, 'lag_info'))
      
    },
    validate_model_tag = function() {
      tag_check <- xgb.attr(self$model, 'model_tag')
      subtag_check <- xgb.attr(self$model, 'model_subtag')
      if (self$model_tag != tag_check) {
        stop(sprintf("Model tag found in file does not match request.\n
                     %s -- %s", self$model_tag, tag_check))
      } else if ((!is.na(self$model_subtag) & self$model_subtag != subtag_check) |
                 (is.na(self$model_subtag) & subtag_check != "NA")){
        stop(sprintf("Model subtag found in file does not match request.\n
                     %s -- %s", self$model_subtag, subtag_check))
      }
      return(invisible())
    },
    parse_eval_params = function() {
      xgb.attr(self$model, 'eval')
    },
    parse_model_timestamp = function() {
      as.POSIXct(xgb.attr(self$model, 'created_at'),
                 format="%Y_%m_%d_%H_%M_%S", tz="UCT")
      
    },
    parse_best_model_params = function() {
      jsonlite::fromJSON(xgb.attr(self$model, 'best_params'))
    },
    parse_session_id = function(){
      xgb.attr(self$model, 'session_id')
    },
    parse_featuremap_from_model = function() {
      fmap = xgb.attr(self$model, 'featuremap')
      FeatureMap$new(model_tag = self$model_tag, 
                     model_subtag = self$model_subtag,
                     file_path=textConnection(fmap))
    }
    
  )
)
