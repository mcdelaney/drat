options(stringsAsFactors=FALSE)
library(testthat)
library(reticulate)

MODEL_TAG = 'test_model'
VERSION = '2017_11_02_09_16_07'
TEST_S3 = FALSE
MODEL_DIR = "/var/folders/gw/zybl3sdx5kx4jv1f3c5249c9zlzsfc/T//RtmpgUWvGW"

data = read.csv('tests/data/test_data.csv')[1:6,]
data[['embarked']][5] = "NA"

model = featuremap::ProdModel$new(model_tag = MODEL_TAG, version = VERSION)
model$import_model(s3=TEST_S3, local_model_store = MODEL_DIR)
r_result = model$score(data = data)

# Load python via reticulate and score data with same model. -------------------
use_python("~/.pyenv/shims/python3", required = TRUE)
featuremap = import('featuremap.ProdModel')
pd = import('pandas')

# Create python data object. ---------------------------------------------------
python_data = pd$DataFrame(as.list(data))

# Initialize python ProdModel and import model. --------------------------------
py_model = featuremap$ProdModel(model_tag=MODEL_TAG, version=VERSION)
py_model$import_model(s3=TEST_S3, local_model_store = MODEL_DIR)

# Test featuremap matrix encoding equality. ------------------------------------
message('Testing featuremap encoding equality...')
test_data_py = as.matrix(py_model$featuremap$encode_data(python_data))
test_data_r = model$featuremap$encode_data(data, as_matrix = T)
feature_names = dimnames(test_data_r)[[2]]
dimnames(test_data_r) <- NULL
expect_identical(test_data_r, test_data_py)

# Score data in python and compare results to R. -------------------------------
py_result = as.numeric(py_model$score(data=python_data))

print(sprintf("R Score Results: [%s]", paste0(r_result, collapse=', ')))
print(sprintf("Py Score Results: [%s]", paste0(py_result, collapse=', ')))

message('Testing that results are identical')
testthat::expect_identical(py_result, r_result)
