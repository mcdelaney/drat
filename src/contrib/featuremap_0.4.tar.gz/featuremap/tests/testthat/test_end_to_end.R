options(stringsAsFactors = FALSE)
library(featuremap)
set.seed(14)

# Set constants for tag and version. -------------------------------------------
MODEL_TAG = 'test_model'
MODEL_SUBTAG = 'subtest'
VERSION = gsub(' |:|-', '_', as.character(Sys.time()))
MODEL_DIR = tempdir()
TEST_S3 = FALSE

# Import test data + set value as 'NA' ensure that it's handled as valid. ------
data = read.csv('tests/data/test_data.csv')
data[['embarked']][5] = "NA"

# Create train and test samples. -----------------------------------------------
train_sample = sample(1:nrow(data), round(0.7 * nrow(data)))
train <- data[train_sample, ]
test <- data[-train_sample, ]

# Create new FeatureMap. -------------------------------------------------------
map = FeatureMap$new(model_tag = MODEL_TAG, model_subtag = MODEL_SUBTAG, 
                     log_level = 'DEBUG')

# Add variables to the FeatureMap. ---------------------------------------------
for (var in names(train)[names(train) != 'response']) {
  if (class(train[[var]]) %in% c('integer', 'numeric')) {
    map$add(variable = var, value = NA, type = 'numeric')
  }else{
    for (value in unique(train[[var]])) {
      # Each categorical/character value must be added seperately.
      # Dont complain.  This is a design choice.
      map$add(variable = var, value = value, type = 'character')
    }
  }
}

#create test data for dealing with list variable type
data_with_list = data
data_with_list$list_v = strsplit(paste(data_with_list$sex, 
                                       data_with_list$embarked), " ")
data_with_list$sex[1:4] = NA
data_with_list$list_v[1:4] = NA

map1 = FeatureMap$new(model_tag = MODEL_TAG, log_level = 'DEBUG')
for (var in names(data_with_list)[names(data_with_list) != 'response']) {
  if (class(data_with_list[[var]]) %in% c('integer', 'numeric')) {
    map1$add(variable = var, value = NA, type = 'numeric')
  }else{
    for (value in unique(unlist(data_with_list[[var]]))) {
      map1$add(variable = var, value = value, type = 'character')
    }
  }
}

sparsem = map1$encode_data(data_with_list)
sparsem1 = map1$encode_data_speed(data_with_list)

testthat::expect_identical(setdiff(map1$dataframe$value[map1$dataframe$variable == "sex"], 
                                   map1$dataframe$value[map1$dataframe$variable == "list_v"]),
                           character(0))
testthat::expect_identical(sparsem[5:nrow(sparsem), "sex__male"], 
                           sparsem[5:nrow(sparsem), "list_v__male"])
testthat::expect_identical(sparsem[5:nrow(sparsem), "embarked__S"], 
                           sparsem[5:nrow(sparsem), "list_v__S"])
testthat::expect_identical(sparsem, sparsem1)

# Test that featuremap import/export yields identical result. ------------------
map$export_map('test_map.csv')
map2 = FeatureMap$new(model_tag = MODEL_TAG, file_path = 'test_map.csv')
testthat::expect_identical(map$encode_data(train), map2$encode_data(train))
file.remove('test_map.csv')

# Create data object for ModelFitter. ------------------------------------------
model_data = map$prepare_model_data(train = train, train_y = train$response, 
                                    test = test, test_y = test$response)

# Create new ModelFitter and add featuremap. -----------------------------------
model = ModelFitter$new(featuremap = map, data = model_data, eval_metric = 'mae')

# Set search params and run CV to find optimal params. -------------------------
model$set_xgb_search_params(subsample = c(0.85), gamma = 0.5,  
                            max_depth = c(40, 10))
model$find_optimal_params()

# Fit final model with optimal params. -----------------------------------------
model$train_final_model()

# Connect to DB for model deployment. ------------------------------------------
con = mmkit::db_conn("test_local")

# Create ProdModel and export. -------------------------------------------------
prod = ProdModel$new(conn = con, model_tag = MODEL_TAG, 
                     model_subtag = MODEL_SUBTAG, 
                     version = VERSION)
path = prod$export_model(model$final_model, s3 = TEST_S3, 
                         local_model_store = MODEL_DIR)

# Create new ProdModel for scoring test data and import exported model. --------
# This also tests that model tag and model subtag are case insensitive.
score = ProdModel$new(conn = con, model_tag = toupper(MODEL_TAG), 
                      model_subtag = toupper(MODEL_SUBTAG), version = VERSION)
score$import_model(s3 = TEST_S3, local_model_store = MODEL_DIR)

# Encode and score test data with ProdModel. -----------------------------------
test = model$data$test
test$result = score$score(data = test)
testthat::expect_equal(prod$score(test), test$result)

# Evaluate that overall error is less than 2.5%. -------------------------------
error = round(((sum(test$result) - sum(test$response))/sum(test$response))*100, 2)
message(sprintf("Overall Error: %.2f%%", error))
testthat::expect_lt(abs(error), 2.5)
message('End to end test successful!')
