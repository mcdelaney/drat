#' @title query_transactor
#' @description A tool to simplify transactor queries.
#' @param conn A valid connection to ODS
#' @param fields List of field names that should be returned. Defaults to all fields.
#' @param sf_domain A salesforce domain-based program name; eg: unc-mba.
#' @param record_ids A dataframe holding the two colums:
#'  lookup_id: id's of records to look up, and
#'  uuid: uuid for cross record attribution.
#' @export

query_transactor <- function(conn, fields = NULL, sf_domain, record_ids) {

 if (!is.data.frame(record_ids) || !all(c("lookup_id", "uuid") %in% names(record_ids))) {
  stop("Record id input is incorrect.  Must be a dataframe with id and uuid columns.")
 }

 message("Querying transactor for id data...")
 sf_domain = gsub("-", "_", sf_domain)

 ref_data <- getrs(conn = conn,
                   "WITH tmp AS (select * FROM ds.transactor_dim_id
                            WHERE id IN ('{{record_ids}}')
                             AND domain_id = (
                            SELECT domain_id FROM ds.transactor_dim_domain
                            WHERE domain = '{{sf_domain}}'))
               SELECT * , (SELECT object FROM ds.transactor_dim_object
                  WHERE object_id = tmp.object_id) AS object FROM tmp",
                   record_ids = sql_lst(record_ids$lookup_id), sf_domain = sf_domain)

 ref_data <- left_join(ref_data, record_ids, by = c("id" = "lookup_id"))

 if (nrow(ref_data) == 0) {
  stop("No rows found in ref data! Exiting.")
 }

 message("Querying event records...")
 events <- getrs(conn = conn, "SELECT * FROM ds.transactor_{{sf_domain}}
                         WHERE object IN ('{{object_ids}}') AND
                         id IN ('{{ids}}') {{field_spec}}",
                 object_ids = sql_lst(ref_data$object_id),
                 sf_domain = sf_domain,
                 field_spec = ifelse(is.null(fields), "",
                                     str_form("AND field IN ('{{fields}}')",
                                              sql_lst(fields))),
                 ids = sql_lst(ref_data$id_id))

 events <- events %>% rename_(.dots = list("field_id" = "field",
                                           "object_id" = "object",
                                           "id_id" = "id"))

 check = nrow(events)
 message("Total event records returned: ", check)

 message("Querying field names...")
 fields <- getrs(conn = conn,
                 "SELECT object_id, field, field_id
                  FROM ds.transactor_dim_field
                  WHERE domain_id in ('{{domain}}') and
                  object_id in ('{{objects}}')",
                 domain = sql_lst(unique(ref_data$domain_id)),
                 objects = sql_lst(unique(ref_data$object_id)))

 message("Joining event records with fields...")
 events <- left_join(events, fields, by = c("field_id", "object_id"))
 events < events[, !names(events) %in% "field_id"]

 if (nrow(events) != check) {
  stop("Error in field name join...Record change total: %s",
       nrow(events) - check)
 }

 events <- left_join(events, ref_data %>%
                      select_(.dots = list("id", "id_id", "object_id", "object")))

 events <- events[,!names(events) %in% c("id_id", "object_id")]

 return(events)
}
