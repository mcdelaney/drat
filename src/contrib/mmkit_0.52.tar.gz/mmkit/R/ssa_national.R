#' @title ssa_national
#' @description A dataframe containing gender classifications for common names,
#' sourced from the r-opensci/genderdata package.
"ssa_national"
