#' @title sch_info
#' @description Returns relevent data for the analysis of scholarship tests
#' @param  prog A Requestsandstudents-style program name. ex - 'UNC-Bus'
#' @param conn A redshift database connection
#' @import RPostgreSQL
#' @import dplyr
#' @export


sch_info <- function(prog, conn=NULL) {

#  if (is.null(conn)) {
#   conn <- findConn()
#  }

 attr.x <- function(x, value, name="record") {
  # works, but joins don't preserve attributes...yet.
  attr(x, name) <- value
  return(x)
 }

 cohort_date <- function(cohort) {
  as.Date(unlist(lapply(cohort, function(x) paste(x,"01"))),
          format = "%B %Y %d")
 }

 clean_state <- function(state) {
  state_lookup <- data.frame(abbrev = c(state.abb, state.abb, "DC","DC","blank"),
                             lookup = tolower(c(state.name, state.abb,
                                                "district of columbia","DC", "blank")))
  state <- ifelse(is.na(state),"blank", tolower(state))
  state <- unlist(state_lookup$abbrev[match(state, state_lookup$lookup)])
  state <- ifelse(is.na(state),"unmatched", state)

  return(state)
 }

 cfg <- collect(tbl(conn, sql("select * from investment_analysis.lookup"))) %>%
  filter(program == prog) %>%
  tidyr::spread(variable, value) %>%
  data.frame()

 sch <- collect(tbl(conn, sql(
  sprintf("select id id15, cohort offer_cohort, date offer_date,
          scholarship_granted, scholarship_amount
          from investment_analysis.scholarships
          where program = '%s'",prog) )))
 # %>% mutate_each(funs(attr.x(.,"schol")))


 xtra <- sapply(c("lead","opp","acc"), function(x) {
  col <- sprintf("extra_%s_cols",x)
  ifelse(col %in% names(cfg), paste(",", cfg[, col]), "")
 }, simplify = F)

 info <- collect(tbl(conn, sql(sprintf(
  "select id as accid, name, %s as type, %s as reg_date, %s as acc_psd
  %s
  %s
  from %s_account_stg where isdeleted = FALSE and %s = TRUE",
  cfg$type_col, cfg$reg_col, cfg$acc_psd,
  ifelse(cfg$has_opp, "", sprintf(", %s as admit_psd", cfg$admit_psd)),
  xtra$acc,
  cfg$stg_name, ifelse(cfg$has_opp, "TRUE", cfg$admit_col)) )))
 # %>% mutate_each(funs(attr.x(.,"acc")))

 if (cfg$has_opp) {
  info <- left_join(
   collect(tbl(conn, sql(sprintf(
    "select id, accountid as accid, %s as opp_psd, %s as admit_psd
    %s
    from %s_opportunity_stg where %s = TRUE and isdeleted = FALSE",
    cfg$opp_psd, ifelse(nchar(cfg$admit_psd), cfg$admit_psd, "''"),
    xtra$opp,
    cfg$stg_name, cfg$admit_col) ))),
   # %>% mutate_each(funs(attr.x(.,"opp"))),
   info, by = "accid")
 } else {
  info <- info %>%
   mutate(id = accid, opp_psd = NA)
 }
 if (nchar(xtra$lead)) {
  id_type <- ifelse(cfg$has_opp,"opportunity","account")
  info <- left_join(
   collect(tbl(conn, sql(sprintf(
    "select converted%sid as id, createddate%s from %s_lead_stg
    where isdeleted = FALSE and converted%sid in('%s')",
    id_type, xtra$lead, cfg$stg_name,
    id_type, paste0(info$id, collapse = "','")) ))) %>%
    arrange(createddate) %>%
    group_by(id) %>%
    filter( !duplicated(id, fromLast = T)) %>%
    select(-createddate) %>% ungroup(),
   # %>% mutate_each(funs(attr.x(.,"lead"))),
   info, by = "id")
 }

 names(info) <- gsub("__(p|)c","",names(info))

 info <- info %>%
  mutate(program     = prog,
         id15        = substring(id,0,15),
         current_psd = ifelse( !acc_psd %in% c("",NA), acc_psd, opp_psd),
         admit_psd   = ifelse(admit_psd %in% c("",NA), current_psd, admit_psd),
         type        = gsub("[ ]{0,}(S|s)tudent","",type),
         registered  = as.numeric( !is.na(reg_date)) )

 info <- left_join(info, sch, by = "id15") %>%
  mutate(scholarship_granted = ifelse(is.na(scholarship_granted), "excluded",
                                      ifelse(scholarship_granted, "awarded",
                                             "control")) ) %>%
  mutate_each(funs(clean_state(.)), matches("(billing|ary)[_]{0,}state")) %>%
  select(-accid, -id15, -acc_psd, -opp_psd) %>%
  rename(category = scholarship_granted,
         appid    = id) %>%
  filter(cohort_date(admit_psd) >= min(cohort_date(sch$offer_cohort), na.rm=T) )

 return(info)
}

