#' @title FeatureMap
#'
#' @description A class to manage model features between training and scoring.
#' 
#' @details \code{Featuremap} addresses an annoying, but common, problem in data science:
#' How do I keep track of enumerated values at scoring time when my build sample
#' has coerced them to a one-hot-encoded matrix.
#' FeatureMap handles this for you, but recording an copy of all field-value
#' pairs, and their order in the resulting matrix.
#' By importing a saved FeatureMap from disk, you can easily ensure that your 
#' test/scoring data matches your build sample exactly.
#' 
#' @field model_tag Name of the FeatureMap
#' @field model_subtag Specifies covariates that correspond to model (e.g. program name, model term); optional
#' @field file_path Path to existing FeatureMap if restoring from previously saved file.
#' 
#' @import logging
#' @import Matrix
#' @import mmkit
#'
#' @export


FeatureMap = R6::R6Class(
  classname='FeatureMap',
  public=list(
    model_tag=NA,
    model_subtag=NA,
    session_id=NA,
    log=NA,
    missing=-1,
    features = list(),
    
    initialize=function(model_tag, model_subtag = '', file_path=NA, log_level='INFO') {
      self$model_tag <- tolower(model_tag)
      self$model_subtag <- tolower(model_subtag)
      self$session_id <- mmkit::uuid()
      private$get_logger(log_level = log_level)
      
      if (!is.na(file_path)) {
        self$log$info('Initializing existing FeatureMap from file...')
        private$load_map(file_path)
      }
      
    },
    
    encode_data = function(data, as_matrix = TRUE) {
      "Given an input dataframe, encode_data will return a one hot encoded matrix."
      self$log$info('Encoding data from feature map with %d rows...', nrow(data))
      
      if (nrow(data) == 0) {
        stop("Total rows must be greater than zero for encoding!")
      }
      
      fnames = unlist(lapply(X = self$list, FUN = function(X) X$feature_name))
      output = matrix(0, nrow = nrow(data), ncol = self$total_features,
                      dimnames = list(NULL, as.character(fnames)))
      
      for (var in names(data)) {
        if ('factor' %in% class(data[[var]])) {
          self$log$warn('Var: %s is of type factor! Coercing to char...', var)
          data[[var]] = as.character(data[[var]])
        }
      }
      
      for (feature in self$list) {
        self$log$debug('Encoding %s', feature$variable)
        # Check that variable being encoded exists in data
        if (!feature$variable %in% c(names(data))) {
          stop(sprintf('Variable %s not found in data!', feature$variable))
        }
        
        if (feature$type == 'character') {
          self$log$debug('Encoding %s / %s', feature$variable, feature$value)
          output[,feature$position] = private$parse_char(data, feature$variable,
                                                         feature$value)
        }else{
          self$log$debug('Encoding %s', feature$variable)
          output[,feature$position] = data[[feature$variable]]
          output[,feature$position][is.na(output[,feature$position])] <- self$missing
        }
      }
      
      if (nrow(data) != nrow(output)) {
        stop('Input data does not have same row count as output!')
      }
      
      self$log$info('Returning encoded data with %d rows and %d columns...',
                    nrow(output),  ncol(output))
      
      if (!as_matrix) {
        output = as.data.frame(output)
        names(output) <- as.character(lapply(self$list, FUN = function(X) X$feature_name))
      }
      else
        output = Matrix::Matrix(output, sparse = TRUE)
      
      return(output)
    },
    
    encode_data_speed = function(data) {
      "Given an input dataframe, encode_data will return a one hot encoded matrix."
      self$log$info('Encoding data from feature map with %d rows...', nrow(data))
      
      if (nrow(data) == 0) {
        stop("Total rows must be greater than zero for encoding!")
      }
      
      fnames = unlist(lapply(X = self$list, FUN = function(X) X$feature_name))
      vars = unname(sapply(X = self$list, FUN = function(X) {result = X$variable}))
      positions = unlist(lapply(X = self$list, FUN = function(X) X$position))
      names(positions) = vars
      vars = unique(vars)
      
      output = Matrix(0, nrow = nrow(data), ncol = self$total_features,
                      dimnames = list(NULL, as.character(fnames)), sparse = T)
      
      for (var in names(data)) {
        if ('factor' %in% class(data[[var]])) {
          self$log$warn('Var: %s is of type factor! Coercing to char...', var)
          data[[var]] = as.character(data[[var]])
        }
      }
      
      index_ls = list()
      onehot_values = c()
      for (variable in vars) {
        if (!variable %in% c(names(data))) {
          stop(sprintf('Variable %s not found in data!', variable))
        }
        self$log$debug('Encoding %s', variable)
        values = data[[variable]]
        if ('character' %in% class(values)) {
          feature_values = paste(variable, values, sep = "__")
          feature_values[is.na(values)] = NA
          row_index = 1:length(values)
          col_index = match(feature_values, fnames)
          index_ls[[variable]] = cbind(row_index[!is.na(col_index)], col_index[!is.na(col_index)])
          onehot_values = c(onehot_values, rep(1, nrow(index_ls[[variable]])))
          ###add NA values
          na_index = row_index[is.na(values)]
          var_col_index = positions[names(positions) == variable]
          na_row_index = rep(na_index, rep(length(var_col_index), length(na_index)))
          na_col_index = rep(var_col_index, length(na_index))
          index_ls[[variable]] = rbind(index_ls[[variable]], cbind(na_row_index, na_col_index))
          onehot_values = c(onehot_values, rep(NA, length(na_row_index)))
        }
        else if ('list' %in% class(values)) {
          feature_values = paste(variable, unlist(values), sep = "__")
          feature_values[is.na(unlist(values))] = NA
          row_index = rep(1:length(values), sapply(values, length))
          col_index = match(feature_values, fnames)
          index_ls[[variable]] = cbind(row_index[!is.na(col_index)], col_index[!is.na(col_index)])
          onehot_values = c(onehot_values, rep(1, nrow(index_ls[[variable]])))
        }
        else {
          values[is.na(values)] = self$missing
          index_ls[[variable]] = cbind(1:length(values), which(fnames == variable))
          onehot_values = c(onehot_values, values)
        }
      }

      onehot_indice = do.call(rbind, index_ls)
    
      output[onehot_indice] = onehot_values
      self$log$info('Returning encoded data with %d rows and %d columns...',
                    nrow(output),  ncol(output))
      return(output)
    },
    
    prepare_model_data = function(train, train_y, test, test_y) {
      
      self$log$info('Preparing data for model fit...')
      
      output = list(
        train = train,
        test = test,
        train_x = self$encode_data(train),
        test_x = self$encode_data(test),
        train_y = train_y,
        test_y = test_y
      )
      
      return(output)
    },
    
    add = function(variable, type, value=NA, load=FALSE, sep = "__") {
      feature_name = ifelse(!is.na(value), paste(variable, value, sep = sep), variable)
      if (!type %in% c('numeric', 'character', 'integer')) { 
        self$log$error('Variable must be numeric, integer, or character!')
        stop()
      }
      
      if (type %in% c('numeric', 'integer') && !is.na(value)) { 
        self$log$error('You obviously cant set a value for numeric/integer variables!')
        stop()
        
      }else if (type == 'character' && class(value) != 'character'){
        self$log$error('You have passed a non-character value to a variable set as character!')
        stop()
      }
      
      if (feature_name %in% c(names(self$features))) {
        self$log$error('Variable: %s with value: %s already added to map!', variable, value)
        stop()
      }
      
      if (type == 'character' & is.na(value)) {
        self$log$warn('Value added is NA...skipping')
        return(invisible())
      }
      
      if (!load) {
        self$log$info('Adding feature to map -- Variable: %s / Value: %s...', variable, 
                      ifelse(type == 'character', value, 'Numeric'))
      }
      
      self$features[[feature_name]] <- list(feature_name = feature_name, variable=variable, 
                                            type=type, value=value,
                                            position=self$total_features+1)
    },
    export_map = function(file_path = NA) {
      
      as_string = FALSE
      
      if (is.na(file_path)) {
        as_string = TRUE
        self$log$info('Saving %s FeatureMap to string', self$model_name)
        file_path = paste0(tempdir(),'/map.csv')
        
      }else{
        
        self$log$info('Saving %s FeatureMap to %s', self$model_name, file_path)
      }
      
      write.csv(self$dataframe, file=file_path, row.names = FALSE, na = '_NA_VAL_')
      
      if (as_string) {
        string_map = paste0(readLines(file_path), collapse = '\n')
        return(string_map)
      }else{
        return(file_path)
      }
      
    }
  ),
  active = list(
    total_features = function() length(self$features),
    dataframe = function() {
      df <- lapply(X = self$features, FUN = as.data.frame)
      df <- do.call('rbind', df)
    },
    list = function() self$features,
    names = function() names(self$features),
    model_name = function(){
      if (is.na(self$model_subtag)){
        self$model_tag
      } else {
        paste(self$model_tag, self$model_subtag, sep = "_")
      }
    }
  ),
  private = list(
    get_logger = function(log_level) {
      self$log <- getLogger('FeatureMap')
      self$log$setLevel(newLevel=log_level)
      self$log$addHandler(writeToConsole)
      self$log$info('Creating FeatureMap for %s', self$model_name)
      
    },
    load_map = function(file_path) {
      existing_map = read.csv(file_path, stringsAsFactors = FALSE, 
                              na.strings = '_NA_VAL_')
      existing_map$value = ifelse(existing_map$type == 'character', 
                                  as.character(existing_map$value), 
                                  existing_map$value)
      
      if (nrow(existing_map) == 0) {
        self$log$error('No rows found in map!')
        stop()
      }
      
      self$log$info('%s features found...', nrow(existing_map))
      for (i in 1:nrow(existing_map)) {
        feature = as.list(existing_map[i,])
        self$add(variable=feature$variable, value=feature$value,
                 type=feature$type, load=TRUE)
      }
    },

    parse_char = function(data, variable, value) {
      # If character vector has length greater than 1 for any rows, unlist 
      # before attempting to parse, as it is nested.  
      # If not, coerce value with vectorized expression.
      if (all(unlist(lapply(data[[variable]], length))==1)) {
        out = as.numeric(data[[variable]] == value)
      }else{
        out = as.numeric(lapply(data[[variable]], function(l, value) {
          value %in% unlist(l)
          }, value = value))
      }
      
      return(out)
    }
  )
)
