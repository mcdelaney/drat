
s3HTTP <- function(verb = "GET",
                   bucket = "",
                   path = "",
                   query = NULL,
                   headers = list(),
                   request_body = "",
                   region,
                   key,
                   secret,
                   ...)
{
    ## let users pass bucket objects as well as bucket names
    if (inherits(bucket, "s3_bucket")){
      bucket <- bucket$Name
    }
    if (region != "us-east-1"){
      url <- paste0("https://s3-", region, ".amazonaws.com/")
    } else {
      url <- "https://s3.amazonaws.com/"
    }
    if (bucket != "")
      url <- paste0(url, bucket)
    if (path != "")
      url <- paste0(url, URLencode(path))
    current <- Sys.time()
    d_timestamp <- format(current, "%Y%m%dT%H%M%SZ", tz = "UTC")
    p <- httr::parse_url(url)
    action <- if (p$path == "") "/" else paste0("/", p$path)

    canonical_headers <- c(list(host = p$hostname,
                              `x-amz-date` = d_timestamp), headers)


    if(is.null(query) && !is.null(p$query))
      query <- p$query
    if(all(sapply(query, is.null)))
      query <- NULL

    if (key == "") {
        headers$`x-amz-date` <- d_timestamp
        Sig <- list()
        H <- do.call(httr::add_headers, headers)
    } else {
        Sig <- signature_v4_auth(
               datetime = d_timestamp,
               region = region,
               service = "s3",
               verb = verb,
               action = action,
               query_args = query,
               canonical_headers = canonical_headers,
               request_body = request_body,
               key = key, secret = secret)
        headers$`x-amz-date` <- d_timestamp
        headers$`x-amz-content-sha256` <- Sig$BodyHash
        headers$Authorization <- Sig$SignatureHeader
        H <- do.call(httr::add_headers, headers)
    }

    if (verb == "GET") {
      r <- httr::GET(url, H, query = query, ...)
    } else if (verb == "HEAD") {
      r <- httr::HEAD(url, H, query = query, ...)
      s <- httr::http_status(r)
      if (s$category == "success") {
          return(TRUE)
      } else {
          message(s$message)
          return(FALSE)
      }
    } else if (verb == "DELETE") {
      r <- httr::DELETE(url, H, query = query, ...)
      s <- httr::http_status(r)
      if (s$category == "success") {
          return(TRUE)
      } else {
          message(s$message)
          return(FALSE)
      }
    } else if (verb == "POST") {
      r <- httr::POST(url, H, query = query, ...)
    } else if (verb == "PUT") {
      if(is.character(request_body) && request_body == "") {
        r <- httr::PUT(url, H, query = query, ...)
      } else if (is.character(request_body) && file.exists(request_body)) {
        r <- httr::PUT(url, H, body = httr::upload_file(request_body), query = query, ...)
      } else {
        r <- httr::PUT(url, H, body = request_body, query = query, ...)
      }
    } else if (verb == "OPTIONS") {
      r <- httr::VERB("OPTIONS", url, H, query = query, ...)
    }
    return(r)
}



signature_v4_auth <- function(datetime,
                              region,
                              service,
                              verb,
                              action,
                              query_args = list(),
                              canonical_headers,
                              request_body,
                              key,
                              secret,
                              algorithm = "AWS4-HMAC-SHA256")
{
    if (is.null(key)) {
        stop("Missing AWS Access Key ID")
    }
    if (is.null(secret)) {
        stop("Missing AWS Secret Access Key")
    }
    date <- substring(datetime, 1, 8)

    R <- canonical_request(verb = verb,
                           canonical_uri = action,
                           query_args = query_args,
                           canonical_headers = canonical_headers,
                           request_body = request_body)

    S <- string_to_sign(algorithm = algorithm,
                        datetime = datetime,
                        region = region,
                        service = service,
                        request_hash = R$hash)

    V4 <- signature_v4(secret = secret,
                       date = date,
                       region = region,
                       service = service,
                       string_to_sign = S)

    credential <- paste(key, date, region, service, "aws4_request", sep = "/")
    sigheader <- paste(algorithm, paste(paste0("Credential=", credential),
                                        paste0("SignedHeaders=", R$headers),
                                        paste0("Signature=", V4),
                                        sep = ", "))

    structure(list(Algorithm = algorithm,
                   Credential = credential,
                   Date = date,
                   SignedHeaders = R$headers,
                   BodyHash = R$body,
                   CanonicalRequest = R$canonical,
                   StringToSign = S,
                   Signature = V4,
                   SignatureHeader = sigheader),
              class = "aws_signature_v4")
}



signature_v4 <- function(secret,
                         date,
                         region,
                         service,
                         string_to_sign)
{
    if (is.null(secret)) {
        stop("Missing AWS Secret Access Key")
    }
    kDate <- hmac(paste0("AWS4", secret), date, "sha256", raw = TRUE)
    kRegion <- hmac(kDate, region, "sha256", raw = TRUE)
    kService <- hmac(kRegion, service, "sha256", raw = TRUE)
    kSigning <- hmac(kService, "aws4_request", "sha256", raw = TRUE)
    signature <- hmac(kSigning, string_to_sign, "sha256")
    return(signature)
}



canonical_request <- function(verb,
                              canonical_uri,
                              query_args,
                              canonical_headers,
                              request_body)
{
    if (is.character(request_body) && file.exists(request_body)) {
        body_hash <- tolower(digest(request_body,
                                    file = TRUE,
                                    algo = "sha256",
                                    serialize = FALSE))
    }
    else {
        body_hash <- tolower(digest(request_body,
                                    algo = "sha256",
                                    serialize = FALSE))
    }
    names(canonical_headers) <- tolower(names(canonical_headers))
    canonical_headers <- canonical_headers[order(names(canonical_headers))]
    header_string <- paste0(names(canonical_headers), ":", canonical_headers,
                            "\n", collapse = "")
    signed_headers <- paste(names(canonical_headers), sep = "",
                            collapse = ";")
    if (length(query_args)) {
        query_args <- unlist(query_args[order(names(query_args))])
        a <- paste0(sapply(names(query_args), URLencode, reserved = TRUE),
                    "=",
                    sapply(as.character(query_args), URLencode, reserved = TRUE))
        query_string <- paste(a, sep = "", collapse = "&")
    }
    else {
        query_string <- ""
    }
    out <- paste(verb, canonical_uri, query_string, header_string,
                 signed_headers, body_hash, sep = "\n")
    return(
        list(headers = signed_headers,
                body = body_hash,
                canonical = out,
                hash = digest(out,
                              algo = "sha256",
                              serialize = FALSE)
                )
        )
}



string_to_sign <- function (algorithm,
                            datetime,
                            region,
                            service,
                            request_hash)
{
    paste(algorithm,
          datetime,
          paste(substring(datetime, 1, 8),
                region,
                service,
                "aws4_request",
                sep = "/"),
          request_hash,
          sep = "\n")
}
